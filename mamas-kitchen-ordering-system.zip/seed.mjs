import { Pool } from "pg";
import bcrypt from "bcryptjs";

const pool = new Pool({ connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db" });

async function run() {
  const client = await pool.connect();
  try {
    // Clean
    await client.query(`TRUNCATE "order_items", "orders", "menu_items", "categories", "users", "reviews", "inventory_items" CASCADE`);

    // categories
    const catInsert = await client.query(`
      INSERT INTO "categories" (name, slug, icon, description) VALUES
      ('Main Meals', 'main-meals', '🍲', 'Pilau, Ugali, Rice, Chapati'),
      ('Vegetables', 'vegetables', '🥬', 'Sukuma wiki, Cabbage, Kales'),
      ('Proteins', 'proteins', '🍗', 'Beef, Chicken, Beans, Ndengu'),
      ('Drinks', 'drinks', '🥤', 'Soda, Juice, Tea, Coffee')
      RETURNING id, name;
    `);
    const catMap = {};
    catInsert.rows.forEach(r => catMap[r.name] = r.id);

    // users
    const adminHash = await bcrypt.hash("kimpeternevil", 10);
    const staffHash = await bcrypt.hash("kimnevilpeter", 10);
    const custHash = await bcrypt.hash("customer123", 10);
    await client.query(`
      INSERT INTO "users" (full_name, email, phone, role, password_hash, loyalty_points, is_active) VALUES
      ('Nevil Peter Kim', 'kimalennevil@gmail.com', '+254717565027', 'admin', $1, 420, true),
      ('Kim Len Nevil', 'kimlennevil@gmail.com', '+254712345678', 'staff', $2, 120, true),
      ('Brian Kipchoge', 'brian@campus.ac.ke', '+254701234567', 'customer', $3, 250, true),
      ('Faith Muthoni', 'faith@campus.ac.ke', '+254702345678', 'customer', $3, 180, true),
      ('Kevin Ochieng', 'kevin@campus.ac.ke', '+254703456789', 'customer', $3, 90, true),
      ('Mercy Chebet', 'mercy@campus.ac.ke', '+254704567890', 'customer', $3, 310, true)
    `, [adminHash, staffHash, custHash]);

    const userRows = await client.query(`SELECT id, email FROM "users"`);
    const brian = userRows.rows.find(r => r.email === 'brian@campus.ac.ke');

    // menu items
    await client.query(`
      INSERT INTO "menu_items" (name, description, price, category_id, image, available, is_featured, is_special, discounted_price, popular_score) VALUES
      ('Beef Pilau + Kachumbari', 'Aromatic coastal pilau with tender beef cubes, served with fresh kachumbari and chili.', 250, $1, null, true, true, true, 199, 98),
      ('Ugali + Sukuma + Beef Stew', 'Kenyan staple — fluffy white ugali, sautéed sukuma wiki, hearty beef stew.', 200, $1, null, true, true, false, null, 96),
      ('Chapati (2) + Ndengu Stew', 'Soft layered chapatis with flavorful green grams (ndengu) stew and avocado.', 150, $1, null, true, true, false, null, 94),
      ('Chicken Fry + Chips + Coleslaw', 'Crispy fried chicken, golden chips and creamy coleslaw.', 320, $1, null, true, true, true, 279, 92),
      ('Rice + Beans + Avocado', 'Budget student combo — steamed rice, beans stew, ripe avocado.', 130, $1, null, true, false, false, null, 90),
      ('Mokimo + Beef', 'Mashed potatoes, peas and corn (mokimo) served with beef stew.', 180, $1, null, true, false, false, null, 88),
      ('Sukuma Wiki', 'Freshly sautéed sukuma wiki with tomatoes and onions.', 50, $2, null, true, false, false, null, 70),
      ('Cabbage Fry', 'Stir-fried cabbage with carrots and spices.', 50, $2, null, true, false, false, null, 65),
      ('Kachumbari', 'Fresh tomato, onion, chili and lemon salad.', 30, $2, null, true, false, false, null, 60),
      ('Beef Stew (Protein)', 'Tender beef stew alone — great add-on.', 120, $3, null, true, false, false, null, 85),
      ('Chicken Stew', 'Juicy chicken in rich tomato gravy.', 150, $3, null, true, true, false, null, 87),
      ('Beans Stew', 'Slow-cooked beans in thick gravy.', 80, $3, null, true, false, false, null, 75),
      ('Soda 300ml', 'Coca-Cola / Fanta / Sprite — chilled.', 50, $4, null, true, false, false, null, 80),
      ('Fresh Juice 300ml', 'Mango or Passion — freshly blended.', 80, $4, null, true, false, true, 60, 82),
      ('Chai (Tea)', 'Kenyan milky tea with ginger — hot.', 40, $4, null, true, false, false, null, 78),
      ('Chapati Single', 'One soft layered chapati.', 30, $1, null, true, false, false, null, 72)
    `, [catMap['Main Meals'], catMap['Vegetables'], catMap['Proteins'], catMap['Drinks']]);

    // inventory
    await client.query(`
      INSERT INTO "inventory_items" (ingredient, quantity, threshold, supplier, unit) VALUES
      ('Rice (Pishori)', 25, 10, 'Eldoret Grains', 'kg'),
      ('Beef', 12, 8, 'Royal Butchery', 'kg'),
      ('Chicken', 8, 10, 'Kenchic Supplier', 'kg'),
      ('Cooking Oil', 15, 5, 'Bidco', 'L'),
      ('Sukuma Wiki', 6, 5, 'Mama Mboga - Royalton', 'kg'),
      ('Chapati Flour', 30, 10, 'Pembe Mills', 'kg'),
      ('Beans', 18, 10, 'Eldoret Grains', 'kg'),
      ('Soda Stock', 48, 20, 'Coca-Cola Depot', 'pcs')
    `);

    // reviews
    await client.query(`
      INSERT INTO "reviews" (customer_name, rating, comment) VALUES
      ('Brian K.', 5, 'Best pilau near campus! Always hot and on time. Mama''s Kitchen is my daily spot.'),
      ('Faith M.', 5, 'Affordable and delicious. Chapati + beans combo is unbeatable for the price.'),
      ('Kevin O.', 4, 'Quick M-Pesa checkout and food was ready in 7 minutes. Recommend!'),
      ('Mercy C.', 5, 'The chicken biryani special is fire 🔥 Will order again tomorrow!'),
      ('Dennis K.', 4, 'Great portions for students. Love the loyalty points system.')
    `);

    // orders demo
    const menuRows = await client.query(`SELECT id, name, price, discounted_price FROM "menu_items"`);
    const pilau = menuRows.rows.find(r => r.name.includes('Pilau'));
    const ugali = menuRows.rows.find(r => r.name.includes('Ugali'));
    const chapati = menuRows.rows.find(r => r.name.includes('Chapati (2)'));

    // Create sample orders
    const o1 = await client.query(`INSERT INTO "orders" (customer_id, customer_name, customer_phone, status, payment_status, payment_method, total, notes) VALUES ($1, 'Brian Kipchoge', '+254701234567', 'completed', 'paid', 'mpesa', 329, 'Extra kachumbari please') RETURNING id`, [brian.id]);
    await client.query(`INSERT INTO "order_items" (order_id, menu_id, quantity, price, name) VALUES ($1, $2, 1, $3, $4), ($1, $5, 1, $6, $7)`, [o1.rows[0].id, pilau.id, pilau.discounted_price || pilau.price, pilau.name, ugali.id, ugali.price, ugali.name]);

    const o2 = await client.query(`INSERT INTO "orders" (customer_id, customer_name, customer_phone, status, payment_status, payment_method, total, notes) VALUES ($1, 'Faith Muthoni', '+254702345678', 'ready', 'paid', 'cash', 150, null) RETURNING id`, [userRows.rows.find(r=>r.email==='faith@campus.ac.ke').id]);
    await client.query(`INSERT INTO "order_items" (order_id, menu_id, quantity, price, name) VALUES ($1, $2, 1, $3, $4)`, [o2.rows[0].id, chapati.id, chapati.price, chapati.name]);

    const o3 = await client.query(`INSERT INTO "orders" (customer_name, customer_phone, status, payment_status, payment_method, total, notes) VALUES ('Guest Student', '+254712000111', 'preparing', 'pending', 'cash', 320, 'Call when ready') RETURNING id`);
    const chicken = menuRows.rows.find(r=> r.name.includes('Chicken Fry'));
    await client.query(`INSERT INTO "order_items" (order_id, menu_id, quantity, price, name) VALUES ($1, $2, 1, $3, $4)`, [o3.rows[0].id, chicken.id, chicken.discounted_price || chicken.price, chicken.name]);

    const o4 = await client.query(`INSERT INTO "orders" (customer_name, customer_phone, status, payment_status, payment_method, total) VALUES ('Mercy Chebet', '+254704567890', 'received', 'paid', 'mpesa', 210) RETURNING id`);
    const juice = menuRows.rows.find(r=> r.name.includes('Juice'));
    await client.query(`INSERT INTO "order_items" (order_id, menu_id, quantity, price, name) VALUES ($1, $2, 2, $3, $4)`, [o4.rows[0].id, juice.id, juice.discounted_price || juice.price, juice.name]);

    console.log("Seed complete");
  } finally {
    await client.release();
    await pool.end();
  }
}
run().catch(e=>{console.error(e); process.exit(1);});
