export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white mt-12">
      <div className="mx-auto max-w-7xl px-6 py-12 grid md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center font-black">M</div>
            <span className="font-extrabold">Mama&apos;s Kitchen</span>
          </div>
          <p className="mt-3 text-sm text-white/70 leading-relaxed">Home-cooked meals for campus students. Fast, affordable & delicious — right at Royalton, Eldoret next to Madonna TTC.</p>
          <div className="mt-4 flex gap-2 text-xs">
            <span className="rounded-full bg-white/10 px-3 py-1">M-Pesa Accepted</span>
            <span className="rounded-full bg-white/10 px-3 py-1">Cash on Pickup</span>
          </div>
        </div>
        <div>
          <div className="font-bold">Quick Links</div>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li>Home</li><li>Menu</li><li>Track Order</li><li>Admin Dashboard</li>
          </ul>
        </div>
        <div>
          <div className="font-bold">Contact</div>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li>📍 Royalton, Eldoret (Next to Madonna TTC)</li>
            <li>📞 +254 717 565 027</li>
            <li>💬 WhatsApp: +254717565027</li>
            <li>🕒 6:30 AM - 9:30 PM Daily</li>
          </ul>
        </div>
        <div>
          <div className="font-bold">We Accept</div>
          <div className="mt-3 rounded-2xl bg-white p-4 text-slate-900">
            <div className="text-xs font-bold tracking-widest uppercase text-slate-500">Lipa na M-Pesa</div>
            <div className="font-black text-green-600 text-lg">STK Push Enabled</div>
            <div className="text-xs text-slate-600 mt-1">Pay on checkout or Cash on pickup. Instant confirmation.</div>
            <a href="https://wa.me/254717565027" target="_blank" className="mt-3 inline-flex w-full justify-center rounded-xl bg-[#25D366] py-2.5 font-bold text-white text-sm">Order on WhatsApp</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/50">© 2026 Mama&apos;s Kitchen — Built for Campus Students. Made with ❤️ in Eldoret.</div>
    </footer>
  );
}
