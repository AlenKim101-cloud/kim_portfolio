"use client";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import { useUser } from "@/lib/userContext";
import { useState } from "react";
import { usePathname, useRouter } from "next/navigation";

export default function Navbar() {
  const { count } = useCart();
  const { user, logout } = useUser();
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    await logout();
    router.push("/");
    router.refresh();
  };

  const isAdmin = user?.role === "admin";
  const isStaff = user?.role === "staff";

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-orange-100">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-[64px] items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-white font-black text-lg shadow-lg">M</div>
            <div className="leading-tight">
              <div className="font-extrabold text-[17px] tracking-tight text-slate-900">Mama&apos;s Kitchen</div>
              <div className="text-[11px] font-semibold tracking-widest text-orange-600 uppercase -mt-1">Royalton • Eldoret</div>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1 bg-slate-900 rounded-full p-1">
            <Link href="/" className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${pathname === "/" ? "bg-white text-slate-900 shadow" : "text-white/80 hover:text-white"}`}>Home</Link>
            <Link href="/menu" className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${pathname === "/menu" ? "bg-white text-slate-900 shadow" : "text-white/80 hover:text-white"}`}>Menu</Link>
            <Link href="/orders" className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${pathname === "/orders" ? "bg-white text-slate-900 shadow" : "text-white/80 hover:text-white"}`}>Track Order</Link>
            {(isAdmin || isStaff) && (
              <Link href="/admin" className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${pathname?.startsWith("/admin") ? "bg-white text-slate-900 shadow" : "text-white/80 hover:text-white"}`}>Dashboard</Link>
            )}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href="https://wa.me/254717565027?text=Hello%20Mama's%20Kitchen!%20I%20want%20to%20place%20an%20order."
              target="_blank"
              className="hidden sm:inline-flex items-center gap-2 rounded-full bg-[#25D366] px-3 py-2 text-sm font-bold text-white shadow hover:bg-[#1ebe5d] transition"
            >
              <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
              WhatsApp
            </a>

            <Link href="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full bg-orange-500 text-white shadow hover:bg-orange-600 transition">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              {count > 0 && <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 text-[11px] font-bold text-white">{count}</span>}
            </Link>

            {user ? (
              <div className="hidden sm:flex items-center gap-2">
                <Link href="/profile" className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 hover:bg-slate-50">
                  <div className="h-7 w-7 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold">{user.fullName[0].toUpperCase()}</div>
                  <span className="text-sm font-semibold max-w-[100px] truncate">{user.fullName.split(" ")[0]}</span>
                </Link>
                <button onClick={handleLogout} className="text-xs font-semibold text-slate-500 hover:text-slate-900 px-2">Logout</button>
              </div>
            ) : (
              <Link href="/login" className="hidden sm:inline-flex rounded-full bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-black">Login</Link>
            )}

            <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <div className="grid grid-cols-3 gap-2">
              <Link href="/" onClick={() => setMenuOpen(false)} className="rounded-xl bg-white border p-3 text-center font-semibold text-sm">Home</Link>
              <Link href="/menu" onClick={() => setMenuOpen(false)} className="rounded-xl bg-white border p-3 text-center font-semibold text-sm">Menu</Link>
              <Link href="/orders" onClick={() => setMenuOpen(false)} className="rounded-xl bg-white border p-3 text-center font-semibold text-sm">Track</Link>
            </div>
            <a href="https://wa.me/254717565027" target="_blank" className="flex w-full justify-center rounded-xl bg-[#25D366] py-3 font-bold text-white">Chat on WhatsApp • +254 717 565 027</a>
            {!user && <Link href="/login" onClick={() => setMenuOpen(false)} className="flex w-full justify-center rounded-xl bg-slate-900 py-3 font-bold text-white">Login / Register</Link>}
            {user && (isAdmin || isStaff) && <Link href="/admin" onClick={() => setMenuOpen(false)} className="flex w-full justify-center rounded-xl bg-orange-500 py-3 font-bold text-white">Go to Dashboard</Link>}
          </div>
        )}
      </div>
      <div className="bg-slate-900 text-white text-center py-1.5 text-xs font-medium tracking-wide">
        📍 Royalton, Eldoret — Next to Madonna TTC • Open 6:30AM - 9:30PM • <a href="tel:+254717565027" className="underline">+254 717 565 027</a>
      </div>
    </header>
  );
}
