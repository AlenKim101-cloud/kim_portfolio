"use client";
import Navbar from "@/components/Navbar";
import { useState } from "react";
import { useUser } from "@/lib/userContext";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { refresh } = useUser();
  const router = useRouter();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const url = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      await refresh();
      if (data.user.role === "admin" || data.user.role === "staff") router.push("/admin");
      else router.push("/menu");
    } catch (err: any) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-[#FFF8F0]">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 py-8 grid md:grid-cols-2 gap-8">
        <div className="rounded-[24px] bg-slate-900 p-8 text-white relative overflow-hidden">
          <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-orange-500/30 blur-2xl" />
          <div className="relative">
            <div className="inline-flex rounded-full bg-white/10 px-3 py-1 text-xs font-bold tracking-widest uppercase">Mama&apos;s Kitchen</div>
            <h1 className="mt-4 text-3xl font-black leading-tight">Welcome back,<br /> hungry scholar!</h1>
            <p className="mt-3 text-white/70 text-sm leading-relaxed">Login to track orders, earn loyalty points, and reorder in 1 tap. Located at Royalton, Eldoret next to Madonna TTC.</p>
            <div className="mt-6 rounded-2xl bg-white p-4 text-slate-900">
              <div className="text-xs font-black uppercase tracking-widest text-orange-600">Demo Accounts</div>
              <div className="mt-2 space-y-2 text-sm">
                <div className="rounded-xl bg-slate-50 p-2.5"><span className="font-bold">Admin</span><br /><span className="text-xs font-mono">kimalennevil@gmail.com / kimpeternevil</span></div>
                <div className="rounded-xl bg-slate-50 p-2.5"><span className="font-bold">Staff</span><br /><span className="text-xs font-mono">kimlennevil@gmail.com / kimnevilpeter</span></div>
              </div>
              <Link href="/menu" className="mt-3 inline-flex w-full justify-center rounded-xl bg-slate-900 py-2.5 text-sm font-bold text-white">Continue as Guest →</Link>
              <div className="mt-2 text-center text-xs text-slate-500">Guests can order without account</div>
            </div>
            <div className="mt-6 flex items-center gap-3 text-xs">
              <span className="h-8 w-8 rounded-full bg-[#25D366] flex items-center justify-center text-white">✆</span>
              <span>Need help? <a href="https://wa.me/254717565027" className="underline font-bold">WhatsApp +254 717 565 027</a></span>
            </div>
          </div>
        </div>

        <div className="rounded-[24px] bg-white border p-6 sm:p-8 shadow-sm">
          <div className="flex rounded-full bg-slate-100 p-1 w-fit">
            <button onClick={() => setMode("login")} className={`rounded-full px-6 py-2 text-sm font-bold ${mode==="login" ? "bg-slate-900 text-white shadow" : "text-slate-600"}`}>Login</button>
            <button onClick={() => setMode("register")} className={`rounded-full px-6 py-2 text-sm font-bold ${mode==="register" ? "bg-slate-900 text-white shadow" : "text-slate-600"}`}>Register</button>
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === "register" && (
              <div>
                <label className="text-xs font-bold">Full Name</label>
                <input required value={form.fullName} onChange={e=>setForm({...form, fullName:e.target.value})} placeholder="e.g. Nevil Kim" className="mt-1 w-full rounded-xl border px-3 py-3 text-sm outline-none focus:border-orange-400" />
              </div>
            )}
            <div>
              <label className="text-xs font-bold">Email</label>
              <input required type="email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="you@campus.ac.ke" className="mt-1 w-full rounded-xl border px-3 py-3 text-sm outline-none focus:border-orange-400" />
            </div>
            {mode==="register" && (
              <div>
                <label className="text-xs font-bold">Phone</label>
                <input value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} placeholder="07xx xxx xxx" className="mt-1 w-full rounded-xl border px-3 py-3 text-sm outline-none focus:border-orange-400" />
              </div>
            )}
            <div>
              <label className="text-xs font-bold">Password</label>
              <input required type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} placeholder="••••••••" className="mt-1 w-full rounded-xl border px-3 py-3 text-sm outline-none focus:border-orange-400" />
            </div>

            {error && <div className="rounded-xl bg-red-50 border border-red-200 p-3 text-sm text-red-700 font-semibold">{error}</div>}

            <button disabled={loading} type="submit" className="w-full rounded-full bg-orange-500 py-3.5 font-black text-white hover:bg-orange-600 disabled:opacity-50">
              {loading ? "Please wait..." : mode==="login" ? "Login →" : "Create Account →"}
            </button>

            <div className="text-center text-xs text-slate-500">
              {mode==="login" ? "No account?" : "Already have account?"}
              <button type="button" onClick={()=>setMode(mode==="login" ? "register" : "login")} className="ml-1 font-bold text-orange-600 hover:underline">{mode==="login" ? "Register" : "Login"}</button>
            </div>
          </form>

          <div className="mt-6 rounded-2xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800">
            <b>Staff / Admin?</b> Use the demo credentials shown on the left to access the dashboard with full management features.
          </div>
        </div>
      </div>
    </div>
  );
}
