"use client";
import { useEffect, useState } from "react";
import { useCart } from "@/lib/cart";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

type MenuItem = {
  id: number;
  name: string;
  description: string | null;
  price: string;
  categoryName: string | null;
  image: string | null;
  available: boolean;
  isFeatured: boolean;
  isSpecial: boolean;
  discountedPrice: string | null;
  popularScore: number;
};

export default function MenuContent() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("all");
  const { addItem } = useCart();
  const searchParams = useSearchParams();

  useEffect(() => {
    const c = searchParams.get("category");
    if (c) setCat(c);
  }, [searchParams]);

  const fetchData = async () => {
    setLoading(true);
    const [menuRes, catRes] = await Promise.all([
      fetch(`/api/menu?search=${encodeURIComponent(search)}&category=${encodeURIComponent(cat)}`).then(r => r.json()),
      fetch("/api/categories").then(r => r.json()).catch(() => []),
    ]);
    setItems(menuRes);
    setCats(catRes);
    setLoading(false);
  };
  useEffect(() => { fetchData(); }, [search, cat]);

  const [searchInput, setSearchInput] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h1 className="text-3xl font-black">Menu</h1>
          <p className="text-sm text-slate-600">Freshly cooked • Available now • Royalton Eldoret</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-[340px]">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">⌕</span>
            <input value={searchInput} onChange={e => setSearchInput(e.target.value)} placeholder="Search pilau, chapati, chicken..." className="w-full rounded-full border border-slate-200 bg-white pl-9 pr-4 py-2.5 text-sm outline-none focus:border-orange-300" />
          </div>
          <Link href="/cart" className="hidden sm:inline-flex rounded-full bg-slate-900 px-6 py-2.5 text-sm font-bold text-white">View Cart</Link>
        </div>
      </div>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button onClick={() => setCat("all")} className={`whitespace-nowrap rounded-full px-5 py-2 text-sm font-bold border ${cat === "all" ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200"}`}>All Meals</button>
        {cats.map((c: any) => (
          <button key={c.id} onClick={() => setCat(c.name)} className={`whitespace-nowrap rounded-full px-5 py-2 text-sm font-bold border flex items-center gap-1.5 ${cat === c.name ? "bg-orange-500 text-white border-orange-500" : "bg-white border-slate-200"}`}>
            <span>{c.icon || "🍲"}</span> {c.name}
          </button>
        ))}
        {cats.length === 0 && (
          <>
            {["Main Meals", "Vegetables", "Proteins", "Drinks"].map(n => (
              <button key={n} onClick={() => setCat(n)} className={`whitespace-nowrap rounded-full px-5 py-2 text-sm font-bold border ${cat === n ? "bg-orange-500 text-white border-orange-500" : "bg-white border-slate-200"}`}>{n}</button>
            ))}
          </>
        )}
      </div>

      {loading ? (
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-[20px] bg-white border p-4 animate-pulse">
              <div className="h-36 bg-slate-100 rounded-2xl" />
              <div className="mt-4 h-4 bg-slate-100 rounded w-2/3" />
              <div className="mt-2 h-3 bg-slate-100 rounded w-full" />
              <div className="mt-4 h-9 bg-slate-100 rounded-full" />
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="mt-12 text-center py-16 bg-white rounded-[24px] border-2 border-dashed">
          <div className="text-5xl">🍽️</div>
          <div className="mt-3 font-black text-lg">No meals found</div>
          <p className="text-sm text-slate-500 mt-1">Try a different search or category. Or ask us on WhatsApp!</p>
          <a href="https://wa.me/254717565027" target="_blank" className="mt-4 inline-flex rounded-full bg-[#25D366] px-6 py-2.5 font-bold text-white">Chat on WhatsApp</a>
        </div>
      ) : (
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map(m => {
            const price = Number(m.discountedPrice ?? m.price);
            const original = m.discountedPrice ? Number(m.price) : null;
            return (
              <div key={m.id} className="rounded-[20px] bg-white border border-slate-100 overflow-hidden flex flex-col hover:shadow-lg transition group">
                <div className="h-40 bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center text-5xl relative">
                  {m.image ? <img src={m.image} alt={m.name} className="h-full w-full object-cover" /> : <span className="group-hover:scale-110 transition">🍛</span>}
                  <div className="absolute left-3 top-3 flex gap-1.5">
                    {m.isSpecial && <span className="rounded-full bg-red-500 px-2.5 py-1 text-[10px] font-black text-white">SPECIAL</span>}
                    {m.isFeatured && <span className="rounded-full bg-slate-900 px-2.5 py-1 text-[10px] font-bold text-white">FEATURED</span>}
                  </div>
                  {!m.available && <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center font-black text-slate-700">Sold Out</div>}
                  <span className="absolute right-3 top-3 rounded-full bg-white px-2 py-1 text-xs font-bold shadow">{m.categoryName || "Meal"}</span>
                </div>
                <div className="p-4 flex-1 flex flex-col">
                  <div className="font-extrabold leading-tight">{m.name}</div>
                  <div className="text-xs text-slate-600 mt-1 line-clamp-2 flex-1">{m.description || "Delicious home-cooked meal, freshly prepared."}</div>
                  <div className="mt-3 flex items-center gap-2">
                    <span className="font-black text-orange-600 text-lg">KSh {price}</span>
                    {original && <span className="text-xs line-through text-slate-400">KSh {original}</span>}
                    <span className={`ml-auto text-xs font-semibold px-2 py-1 rounded-full ${m.available ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>{m.available ? "Available" : "Unavailable"}</span>
                  </div>
                  <button
                    disabled={!m.available}
                    onClick={() => {
                      addItem({ id: m.id, name: m.name, price: Number(m.price), discountedPrice: m.discountedPrice ? Number(m.discountedPrice) : null, image: m.image }, 1);
                    }}
                    className="mt-3 w-full rounded-full bg-slate-900 py-2.5 font-bold text-white text-sm hover:bg-black disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                    Add to Cart
                  </button>
                  <a href={`https://wa.me/254717565027?text=Hello%20Mama's%20Kitchen!%20I%20want%20to%20order%20${encodeURIComponent(m.name)}%20-%20KSh%20${price}`} target="_blank" className="mt-2 text-center text-xs font-bold text-[#25D366] hover:underline">Order on WhatsApp →</a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
