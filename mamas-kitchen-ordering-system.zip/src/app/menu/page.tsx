import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Suspense } from "react";
import MenuContent from "./MenuContent";

export const dynamic = "force-dynamic";

export default function MenuPage() {
  return (
    <div className="min-h-screen bg-[#FFF8F0]">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        <Suspense fallback={<div className="p-8 text-center">Loading menu…</div>}>
          <MenuContent />
        </Suspense>
      </div>
      <Footer />
    </div>
  );
}
