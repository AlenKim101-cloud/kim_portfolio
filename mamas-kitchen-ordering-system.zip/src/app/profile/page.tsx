"use client";
import Navbar from "@/components/Navbar";
import { useUser } from "@/lib/userContext";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function ProfilePage() {
  const { user, loading } = useUser();
  const [orders, setOrders] = useState<any[]>([]);
  const [loyalty, setLoyalty] = useState(0);

  useEffect(() => {
    if (user) {
      fetch("/api/auth/me").then(r=>r.json()).then(d=> setLoyalty(d.user?.loyaltyPoints||0)).catch(()=>{});
      fetch("/api/orders?mine=true").then(r=>r.json()).then(setOrders).catch(()=>{});
    }
  }, [user]);

  if (loading) return <div className="min-h-screen bg-[#FFF8F0]"><Navbar /><div className="p-12 text-center">Loading...</div></div>;
  if (!user) return (
    <div className="min-h-screen bg-[#FFF8F0]"><Navbar />
      <div className="mx-auto max-w-xl px-4 py-12">
        <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center">
          <div className="text-5xl">🔒</div>
          <div className="mt-3 font-black text-lg">Login to view profile</div>
          <p className="text-sm text-slate-500">See your orders, loyalty points, and favorites.</p>
          <Link href="/login" className="mt-6 inline-flex rounded-full bg-slate-900 px-7 py-3 font-bold text-white">Login / Register</Link>
        </div>
      </div>
    </div>
  );

  const totalSpent = orders.reduce((s, o)=> s+Number(o.total), 0);

  return (
    <div className="min-h-screen bg-[#FFF8F0]">
      <Navbar />
      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="rounded-[24px] bg-gradient-to-br from-slate-900 to-slate-800 p-6 sm:p-8 text-white flex flex-wrap gap-6 items-center">
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center text-2xl font-black">{user.fullName[0]}</div>
          <div className="flex-1">
            <div className="text-xl font-black">{user.fullName}</div>
            <div className="text-sm text-white/70">{user.email} • {user.phone || "No phone"} • {user.role}</div>
          </div>
          <div className="rounded-2xl bg-white text-slate-900 p-4 min-w-[180px]">
            <div className="text-xs font-black tracking-widest uppercase text-orange-600">Loyalty Points</div>
            <div className="text-3xl font-black">{loyalty} pts</div>
            <div className="text-xs text-slate-500">10 pts per KSh 100 • Free meal at 500 pts</div>
            <div className="mt-2 h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-orange-500" style={{ width: `${Math.min(100, (loyalty/500)*100)}%` }} /></div>
          </div>
        </div>

        <div className="mt-6 grid md:grid-cols-3 gap-4">
          <div className="rounded-2xl bg-white border p-5"><div className="text-xs font-bold uppercase tracking-wide text-slate-500">Total Orders</div><div className="text-3xl font-black mt-1">{orders.length}</div></div>
          <div className="rounded-2xl bg-white border p-5"><div className="text-xs font-bold uppercase tracking-wide text-slate-500">Total Spent</div><div className="text-3xl font-black mt-1">KSh {totalSpent.toFixed(0)}</div></div>
          <div className="rounded-2xl bg-white border p-5"><div className="text-xs font-bold uppercase tracking-wide text-slate-500">Saved Address</div><div className="text-sm font-bold mt-1">Royalton, Eldoret</div><div className="text-xs text-slate-500">Next to Madonna TTC</div></div>
        </div>

        <div className="mt-6 rounded-[24px] bg-white border p-6">
          <div className="flex items-center justify-between"><h2 className="font-black text-lg">Previous Orders</h2><Link href="/orders" className="text-sm font-bold text-orange-600">Track →</Link></div>
          {orders.length===0 ? <div className="mt-6 rounded-2xl bg-slate-50 border-2 border-dashed p-8 text-center text-sm text-slate-500">No orders yet. Your delicious history will appear here.</div> : (
            <div className="mt-4 space-y-3">
              {orders.slice(0,5).map(o=>(
                <div key={o.id} className="rounded-2xl border p-4 flex justify-between items-center">
                  <div><div className="font-bold">Order #{o.id} • KSh {Number(o.total).toFixed(0)}</div><div className="text-xs text-slate-500">{new Date(o.createdAt).toLocaleString()} • {o.status}</div></div>
                  <span className="rounded-full bg-slate-900 text-white px-3 py-1 text-xs font-bold capitalize">{o.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-6 rounded-[24px] bg-white border p-6">
          <h3 className="font-black">Favorites ❤️</h3>
          <p className="text-sm text-slate-500">Your most ordered meals (coming soon — reorder in 1 tap)</p>
          <div className="mt-4 flex gap-2 flex-wrap">
            {["Pilau", "Chapati + Beans", "Chicken Chips"].map(f=> <span key={f} className="rounded-full bg-orange-50 border border-orange-200 px-4 py-2 text-sm font-bold">🍛 {f}</span>)}
          </div>
        </div>
      </div>
    </div>
  );
}
