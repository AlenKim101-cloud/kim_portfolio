import { NextResponse, NextRequest } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET() {
  const cats = await db.select().from(categories);
  return NextResponse.json(cats);
}

export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { name, icon, description } = await req.json();
  if (!name) return NextResponse.json({ error: "Missing name" }, { status: 400 });
  const slug = name.toLowerCase().replace(/\s+/g, "-");
  const [created] = await db.insert(categories).values({ name, slug, icon, description }).returning();
  return NextResponse.json(created);
}
