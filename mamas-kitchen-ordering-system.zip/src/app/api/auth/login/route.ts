import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { comparePassword, signToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();
  if (!email || !password) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  const found = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!found.length) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  const user = found[0];
  if (!user.isActive) return NextResponse.json({ error: "Account disabled" }, { status: 403 });
  const ok = await comparePassword(password, user.passwordHash);
  if (!ok) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

  const token = signToken({ id: user.id, email: user.email, role: user.role, fullName: user.fullName });
  const res = NextResponse.json({ user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role } });
  res.cookies.set("token", token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60*60*24*7 });
  return res;
}
