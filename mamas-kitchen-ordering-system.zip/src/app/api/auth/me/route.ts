import { NextRequest, NextResponse } from "next/server";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  if (!token) return NextResponse.json({ user: null }, { status: 401 });
  const payload = verifyToken(token);
  if (!payload) return NextResponse.json({ user: null }, { status: 401 });
  const found = await db.select().from(users).where(eq(users.id, payload.id)).limit(1);
  if (!found.length) return NextResponse.json({ user: null }, { status: 401 });
  const u = found[0];
  return NextResponse.json({ user: { id: u.id, email: u.email, fullName: u.fullName, role: u.role, phone: u.phone, loyaltyPoints: u.loyaltyPoints } });
}
