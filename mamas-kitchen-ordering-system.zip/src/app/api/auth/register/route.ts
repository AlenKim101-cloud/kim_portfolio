import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, signToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { fullName, email, phone, password } = await req.json();
  if (!fullName || !email || !password) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return NextResponse.json({ error: "Email already registered" }, { status: 400 });

  const passwordHash = await hashPassword(password);
  const [created] = await db.insert(users).values({
    fullName,
    email,
    phone,
    passwordHash,
    role: "customer",
  }).returning();

  const token = signToken({ id: created.id, email: created.email, role: created.role, fullName: created.fullName });
  const res = NextResponse.json({ user: { id: created.id, email: created.email, fullName: created.fullName, role: created.role } });
  res.cookies.set("token", token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60*60*24*7 });
  return res;
}
