import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { menuItems, categories } from "@/db/schema";
import { eq, ilike, or, and } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search");
  const category = searchParams.get("category");
  const featured = searchParams.get("featured");
  const special = searchParams.get("special");

  let items = await db.select({
    id: menuItems.id,
    name: menuItems.name,
    description: menuItems.description,
    price: menuItems.price,
    categoryId: menuItems.categoryId,
    categoryName: categories.name,
    image: menuItems.image,
    available: menuItems.available,
    isFeatured: menuItems.isFeatured,
    isSpecial: menuItems.isSpecial,
    discountedPrice: menuItems.discountedPrice,
    popularScore: menuItems.popularScore,
  }).from(menuItems).leftJoin(categories, eq(menuItems.categoryId, categories.id));

  if (search) {
    const s = search.toLowerCase();
    items = items.filter(i => i.name.toLowerCase().includes(s) || (i.categoryName?.toLowerCase().includes(s) ?? false) || (i.description?.toLowerCase().includes(s) ?? false));
  }
  if (category && category !== "all") items = items.filter(i => i.categoryName === category || String(i.categoryId) === category);
  if (featured === "true") items = items.filter(i => i.isFeatured);
  if (special === "true") items = items.filter(i => i.isSpecial);

  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { name, description, price, categoryId, image, available, isFeatured, isSpecial, discountedPrice } = body;
  if (!name || !price) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const [created] = await db.insert(menuItems).values({
    name,
    description,
    price: String(price),
    categoryId: categoryId ? Number(categoryId) : null,
    image,
    available: available ?? true,
    isFeatured: isFeatured ?? false,
    isSpecial: isSpecial ?? false,
    discountedPrice: discountedPrice ? String(discountedPrice) : null,
  }).returning();
  return NextResponse.json(created);
}
