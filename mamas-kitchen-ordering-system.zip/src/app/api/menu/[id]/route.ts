import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { menuItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const body = await req.json();
  const update: any = {};
  if (body.name !== undefined) update.name = body.name;
  if (body.description !== undefined) update.description = body.description;
  if (body.price !== undefined) update.price = String(body.price);
  if (body.categoryId !== undefined) update.categoryId = body.categoryId ? Number(body.categoryId) : null;
  if (body.image !== undefined) update.image = body.image;
  if (body.available !== undefined) update.available = body.available;
  if (body.isFeatured !== undefined) update.isFeatured = body.isFeatured;
  if (body.isSpecial !== undefined) update.isSpecial = body.isSpecial;
  if (body.discountedPrice !== undefined) update.discountedPrice = body.discountedPrice ? String(body.discountedPrice) : null;

  const [updated] = await db.update(menuItems).set(update).where(eq(menuItems.id, Number(id))).returning();
  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await db.delete(menuItems).where(eq(menuItems.id, Number(id)));
  return NextResponse.json({ ok: true });
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const found = await db.select().from(menuItems).where(eq(menuItems.id, Number(id))).limit(1);
  if (!found.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(found[0]);
}
