import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const list = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(10);
  return NextResponse.json(list);
}
export async function POST(req: NextRequest) {
  const { customerName, rating, comment } = await req.json();
  if (!customerName || !rating || !comment) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const [created] = await db.insert(reviews).values({ customerName, rating: Number(rating), comment }).returning();
  return NextResponse.json(created);
}
