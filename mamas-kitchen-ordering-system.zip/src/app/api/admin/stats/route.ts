import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, menuItems, inventoryItems, users } from "@/db/schema";
import { eq, sql, desc, gte } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const allOrders = await db.select().from(orders);
  const today = new Date(); today.setHours(0,0,0,0);
  const todayOrders = allOrders.filter(o => new Date(o.createdAt) >= today);
  const revenueToday = todayOrders.reduce((s, o) => s + Number(o.total), 0);
  const pending = allOrders.filter(o => o.status === "received" || o.status === "preparing").length;
  const completed = allOrders.filter(o => o.status === "completed").length;

  const lowStock = await db.select().from(inventoryItems);
  const lowStockCount = lowStock.filter(i => i.quantity <= i.threshold).length;

  const popular = await db.select().from(menuItems).orderBy(desc(menuItems.popularScore)).limit(5);

  // revenue last 7 days
  const last7 = Array.from({ length: 7 }).map((_, idx) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - idx)); d.setHours(0,0,0,0);
    const next = new Date(d); next.setDate(d.getDate() + 1);
    const dayOrders = allOrders.filter(o => {
      const cd = new Date(o.createdAt);
      return cd >= d && cd < next;
    });
    return { date: d.toLocaleDateString("en-KE", { month: "short", day: "numeric" }), revenue: dayOrders.reduce((s, o) => s + Number(o.total), 0), orders: dayOrders.length };
  });

  const totalCustomers = (await db.select().from(users).where(eq(users.role, "customer"))).length;

  return NextResponse.json({
    revenueToday,
    todayOrders: todayOrders.length,
    pending,
    completed,
    lowStockCount,
    popular,
    last7,
    totalCustomers,
    totalOrders: allOrders.length,
    totalRevenue: allOrders.reduce((s, o) => s + Number(o.total), 0),
  });
}
