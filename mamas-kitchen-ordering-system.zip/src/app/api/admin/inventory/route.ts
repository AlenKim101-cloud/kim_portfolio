import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { inventoryItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || (payload.role !== "admin" && payload.role !== "staff")) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await db.select().from(inventoryItems);
  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { ingredient, quantity, threshold, supplier, unit } = await req.json();
  const [created] = await db.insert(inventoryItems).values({ ingredient, quantity: Number(quantity), threshold: Number(threshold), supplier, unit }).returning();
  return NextResponse.json(created);
}

export async function PATCH(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id, quantity } = await req.json();
  const [updated] = await db.update(inventoryItems).set({ quantity: Number(quantity) }).where(eq(inventoryItems.id, Number(id))).returning();
  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db.delete(inventoryItems).where(eq(inventoryItems.id, Number(id)));
  return NextResponse.json({ ok: true });
}
