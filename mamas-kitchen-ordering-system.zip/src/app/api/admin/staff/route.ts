import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";
import { hashPassword } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const staff = await db.select().from(users).where(or(eq(users.role, "staff"), eq(users.role, "admin")));
  return NextResponse.json(staff);
}

export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { fullName, email, phone, password, role } = await req.json();
  if (!fullName || !email || !password) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return NextResponse.json({ error: "Email exists" }, { status: 400 });
  const passwordHash = await hashPassword(password);
  const [created] = await db.insert(users).values({ fullName, email, phone, passwordHash, role: role || "staff" }).returning();
  return NextResponse.json(created);
}

export async function DELETE(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db.delete(users).where(eq(users.id, Number(id)));
  return NextResponse.json({ ok: true });
}
