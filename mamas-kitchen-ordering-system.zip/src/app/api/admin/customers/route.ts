import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const customers = await db.select().from(users).where(eq(users.role, "customer"));
  const allOrders = await db.select().from(orders);
  const enriched = customers.map(c => {
    const custOrders = allOrders.filter(o => o.customerId === c.id);
    const totalSpent = custOrders.reduce((s, o) => s + Number(o.total), 0);
    return { ...c, totalOrders: custOrders.length, totalSpent };
  });
  return NextResponse.json(enriched);
}

export async function PATCH(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || payload.role !== "admin") return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id, action } = await req.json();
  if (action === "toggleActive") {
    const found = await db.select().from(users).where(eq(users.id, Number(id))).limit(1);
    if (!found.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const [updated] = await db.update(users).set({ isActive: !found[0].isActive }).where(eq(users.id, Number(id))).returning();
    return NextResponse.json(updated);
  }
  if (action === "resetLoyalty") {
    const [updated] = await db.update(users).set({ loyaltyPoints: 0 }).where(eq(users.id, Number(id))).returning();
    return NextResponse.json(updated);
  }
  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}
