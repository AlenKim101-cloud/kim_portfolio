import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  const { searchParams } = new URL(req.url);
  const mine = searchParams.get("mine");

  if (mine === "true" && payload) {
    const list = await db.select().from(orders).where(eq(orders.customerId, payload.id)).orderBy(desc(orders.createdAt));
    const withItems = await Promise.all(list.map(async o => {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      return { ...o, items };
    }));
    return NextResponse.json(withItems);
  }

  // For admin/staff view all, for customer without token return empty or check phone? allow guest? fallback to all if admin
  if (payload && (payload.role === "admin" || payload.role === "staff")) {
    const list = await db.select().from(orders).orderBy(desc(orders.createdAt));
    const withItems = await Promise.all(list.map(async o => {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      return { ...o, items };
    }));
    return NextResponse.json(withItems);
  }

  // public fallback - limited? Return empty
  return NextResponse.json([]);
}

export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;

  const body = await req.json();
  const { customerName, customerPhone, notes, paymentMethod, items, total } = body;
  if (!customerName || !customerPhone || !items || !items.length) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }
  const computedTotal = items.reduce((s: number, i: any) => s + Number(i.price) * Number(i.quantity), 0);

  const [order] = await db.insert(orders).values({
    customerId: payload?.id ?? null,
    customerName,
    customerPhone,
    notes,
    paymentMethod: paymentMethod || "cash",
    paymentStatus: paymentMethod === "mpesa" ? "paid" : "pending",
    status: "received",
    total: String(total ?? computedTotal),
  }).returning();

  for (const it of items) {
    await db.insert(orderItems).values({
      orderId: order.id,
      menuId: Number(it.id),
      quantity: Number(it.quantity),
      price: String(it.price),
      name: it.name,
    });
  }

  // award loyalty points: 10 points per 100 KES
  if (payload) {
    const points = Math.floor(Number(total ?? computedTotal) / 100) * 10;
    const user = await db.select().from(users).where(eq(users.id, payload.id)).limit(1);
    if (user.length) {
      await db.update(users).set({ loyaltyPoints: (user[0].loyaltyPoints || 0) + points }).where(eq(users.id, payload.id));
    }
  }

  const orderWithItems = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return NextResponse.json({ ...order, items: orderWithItems });
}
