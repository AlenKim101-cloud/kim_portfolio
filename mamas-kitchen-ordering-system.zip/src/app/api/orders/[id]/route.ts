import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyToken, getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const found = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  if (!found.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, Number(id)));
  return NextResponse.json({ ...found[0], items });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const token = getTokenFromRequest(req);
  const payload = token ? verifyToken(token) : null;
  if (!payload || (payload.role !== "admin" && payload.role !== "staff")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const body = await req.json();
  const update: any = {};
  if (body.status) update.status = body.status;
  if (body.paymentStatus) update.paymentStatus = body.paymentStatus;
  const [updated] = await db.update(orders).set(update).where(eq(orders.id, Number(id))).returning();
  return NextResponse.json(updated);
}
