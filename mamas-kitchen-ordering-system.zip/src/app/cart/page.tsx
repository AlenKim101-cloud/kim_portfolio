"use client";
import Navbar from "@/components/Navbar";
import { useCart } from "@/lib/cart";
import { useUser } from "@/lib/userContext";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function CartPage() {
  const { items, updateQty, removeItem, total, clear } = useCart();
  const { user } = useUser();
  const router = useRouter();
  const [form, setForm] = useState({ name: user?.fullName || "", phone: user?.phone || "", notes: "", paymentMethod: "cash" as "cash"|"mpesa" });
  const [loading, setLoading] = useState(false);
  const [mpesaPhone, setMpesaPhone] = useState("");

  const handleCheckout = async () => {
    if (!items.length) return;
    if (!form.name || !form.phone) { alert("Please enter name and phone number"); return; }
    if (form.paymentMethod === "mpesa" && !mpesaPhone) { alert("Enter M-Pesa phone number"); return; }
    setLoading(true);
    try {
      const payload = {
        customerName: form.name,
        customerPhone: form.paymentMethod === "mpesa" ? mpesaPhone : form.phone,
        notes: form.notes,
        paymentMethod: form.paymentMethod,
        items: items.map(i => ({ id: i.id, name: i.name, price: i.discountedPrice ?? i.price, quantity: i.quantity })),
        total,
      };
      const res = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) throw new Error(await res.text());
      const order = await res.json();
      clear();
      router.push(`/orders?success=${order.id}`);
    } catch (e: any) {
      alert(e.message || "Checkout failed");
    } finally { setLoading(false); }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#FFF8F0]">
        <Navbar />
        <div className="mx-auto max-w-3xl px-4 py-12">
          <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center">
            <div className="text-6xl">🛒</div>
            <h1 className="mt-4 text-2xl font-black">Your cart is empty</h1>
            <p className="mt-2 text-sm text-slate-500">Hungry? Browse our menu and add your favorite meals — ready in minutes at Royalton Eldoret.</p>
            <div className="mt-6 flex justify-center gap-3">
              <Link href="/menu" className="rounded-full bg-orange-500 px-7 py-3 font-bold text-white">Browse Menu</Link>
              <a href="https://wa.me/254717565027" target="_blank" className="rounded-full bg-[#25D366] px-7 py-3 font-bold text-white">WhatsApp Order</a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF8F0]">
      <Navbar />
      <div className="mx-auto max-w-6xl px-4 py-6 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <h1 className="text-2xl font-black">Your Cart <span className="text-sm font-semibold text-slate-500">({items.length} items)</span></h1>
          <div className="mt-4 space-y-3">
            {items.map(it => (
              <div key={it.id} className="rounded-2xl bg-white border p-4 flex gap-4 items-center">
                <div className="h-16 w-16 rounded-xl bg-orange-100 flex items-center justify-center text-2xl flex-shrink-0">🍛</div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold leading-tight truncate">{it.name}</div>
                  <div className="text-sm font-black text-orange-600">KSh {it.discountedPrice ?? it.price} <span className="text-xs font-normal text-slate-500">each</span></div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(it.id, it.quantity - 1)} className="h-8 w-8 rounded-full border bg-white flex items-center justify-center font-bold">−</button>
                  <span className="w-8 text-center font-bold">{it.quantity}</span>
                  <button onClick={() => updateQty(it.id, it.quantity + 1)} className="h-8 w-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold">+</button>
                </div>
                <div className="text-right hidden sm:block">
                  <div className="font-black">KSh {( (it.discountedPrice ?? it.price) * it.quantity ).toFixed(0)}</div>
                  <button onClick={() => removeItem(it.id)} className="text-xs font-bold text-red-500 hover:underline">Remove</button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <button onClick={clear} className="rounded-full border bg-white px-5 py-2 text-sm font-bold">Clear Cart</button>
            <Link href="/menu" className="rounded-full bg-white border px-5 py-2 text-sm font-bold">+ Add More</Link>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="rounded-[24px] bg-white border p-6 sticky top-[80px]">
            <h2 className="font-black text-lg">Checkout</h2>
            <p className="text-xs text-slate-500">Pickup at Royalton, Eldoret next to Madonna TTC</p>

            <div className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-bold">Full Name *</label>
                <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="e.g. John Kamau" className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm outline-none focus:border-orange-300" />
              </div>
              <div>
                <label className="text-xs font-bold">Phone Number *</label>
                <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="07xx xxx xxx" className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm outline-none focus:border-orange-300" />
              </div>
              <div>
                <label className="text-xs font-bold">Notes (optional)</label>
                <textarea value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} placeholder="Extra chili? No onions? Let us know" rows={2} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm outline-none focus:border-orange-300" />
              </div>

              <div>
                <label className="text-xs font-bold">Payment Method</label>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  <button onClick={() => setForm({...form, paymentMethod: "cash"})} className={`rounded-xl border-2 p-3 text-left ${form.paymentMethod === "cash" ? "border-slate-900 bg-slate-50" : "border-slate-200"}`}>
                    <div className="font-bold text-sm">💵 Cash on Pickup</div><div className="text-xs text-slate-500">Pay at kiosk</div>
                  </button>
                  <button onClick={() => setForm({...form, paymentMethod: "mpesa"})} className={`rounded-xl border-2 p-3 text-left ${form.paymentMethod === "mpesa" ? "border-green-600 bg-green-50" : "border-slate-200"}`}>
                    <div className="font-bold text-sm text-green-700">📱 M-Pesa STK</div><div className="text-xs text-slate-500">Lipa na M-Pesa</div>
                  </button>
                </div>
                {form.paymentMethod === "mpesa" && (
                  <div className="mt-2">
                    <input value={mpesaPhone} onChange={e => setMpesaPhone(e.target.value)} placeholder="M-Pesa phone: 2547xxxxxxxx" className="w-full rounded-xl border border-green-300 px-3 py-2.5 text-sm outline-none focus:border-green-500 bg-green-50" />
                    <p className="text-[11px] text-green-700 mt-1">You&apos;ll receive STK push prompt on this number (demo: auto-confirmed)</p>
                  </div>
                )}
              </div>

              <div className="rounded-2xl bg-slate-50 p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-600">Subtotal</span><span className="font-bold">KSh {total.toFixed(0)}</span></div>
                <div className="flex justify-between"><span className="text-slate-600">Service fee</span><span className="font-bold text-green-600">FREE</span></div>
                <div className="h-px bg-slate-200" />
                <div className="flex justify-between text-base"><span className="font-black">Total</span><span className="font-black text-orange-600">KSh {total.toFixed(0)}</span></div>
                <div className="text-[11px] text-slate-500">Earn {Math.floor(total/100)*10} loyalty points with this order 🎉</div>
              </div>

              <button onClick={handleCheckout} disabled={loading} className="w-full rounded-full bg-orange-500 py-3.5 font-black text-white shadow hover:bg-orange-600 disabled:opacity-50 flex items-center justify-center gap-2">
                {loading ? "Placing order..." : form.paymentMethod === "mpesa" ? "Pay with M-Pesa →" : "Place Order — Cash on Pickup"}
              </button>
              <p className="text-center text-[11px] text-slate-500">By placing order you agree pickup at Royalton, Eldoret. Avg. ready time 8-12 mins.</p>
              <a href="https://wa.me/254717565027" target="_blank" className="flex w-full justify-center rounded-full bg-[#25D366] py-2.5 text-sm font-bold text-white">Or Order via WhatsApp</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
