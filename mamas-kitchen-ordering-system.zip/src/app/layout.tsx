import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/lib/cart";
import { UserProvider } from "@/lib/userContext";

export const metadata: Metadata = {
  title: "Mama's Kitchen | Campus Kiosk - Royalton Eldoret",
  description: "Mama's Kitchen - Fast, affordable meals for campus students at Royalton, Eldoret next to Madonna TTC. Order online, pay with M-Pesa, pickup in minutes.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#FFF8F0] text-slate-900 antialiased selection:bg-orange-200">
        <UserProvider>
          <CartProvider>{children}</CartProvider>
        </UserProvider>
      </body>
    </html>
  );
}
