import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Link from "next/link";
import { db } from "@/db";
import { menuItems, categories, reviews, orders, orderItems } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function getData() {
  try {
    const cats = await db.select().from(categories);
    const featured = await db.select().from(menuItems).where(eq(menuItems.isFeatured, true)).limit(6);
    const specials = await db.select().from(menuItems).where(eq(menuItems.isSpecial, true)).limit(3);
    const popular = await db.select().from(menuItems).orderBy(desc(menuItems.popularScore)).limit(4);
    const revs = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(3);
    // fallback if empty (before seed)
    return { cats, featured, specials, popular, revs };
  } catch {
    return { cats: [], featured: [], specials: [], popular: [], revs: [] };
  }
}

export default async function HomePage() {
  const { cats, featured, specials, popular, revs } = await getData();

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* HERO */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6">
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 rounded-[32px] bg-gradient-to-br from-orange-500 via-amber-500 to-orange-600 p-8 sm:p-10 text-white relative overflow-hidden shadow-xl">
            <div className="absolute -right-10 -top-10 h-64 w-64 rounded-full bg-white/15 blur-2xl" />
            <div className="absolute -bottom-20 -left-10 h-64 w-64 rounded-full bg-black/10 blur-2xl" />
            <div className="relative">
              <div className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-bold text-orange-600">
                <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" /> LIVE KIOSK • Ready in 8 mins avg
              </div>
              <h1 className="mt-4 text-[36px] sm:text-[48px] font-black leading-[0.95] tracking-tight">
                Campus meals,<br /> <span className="text-white/90">mama&apos;s taste.</span>
              </h1>
              <p className="mt-3 text-white/90 text-[17px] leading-relaxed max-w-xl">
                Skip the queue. Order your favorite Kenyan meals from <b>Royalton, Eldoret next to Madonna TTC</b> — hot, fresh & affordable. M-Pesa or cash.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/menu" className="rounded-full bg-slate-900 px-7 py-3.5 font-black text-white shadow-lg hover:bg-black transition">Order Now — From KSh 120</Link>
                <a href="https://wa.me/254717565027?text=Hello%20Mama's%20Kitchen,%20I%20want%20to%20order!" target="_blank" className="rounded-full bg-white px-6 py-3.5 font-bold text-slate-900 flex items-center gap-2 hover:bg-slate-50">
                  <span className="h-8 w-8 rounded-full bg-[#25D366] flex items-center justify-center text-white text-sm">✆</span> WhatsApp +254 717 565 027
                </a>
              </div>

              <div className="mt-8 grid grid-cols-3 gap-4 max-w-lg">
                <div className="rounded-2xl bg-white/15 backdrop-blur p-3">
                  <div className="text-2xl font-black">1k+</div><div className="text-xs font-semibold text-white/80">Happy Students</div>
                </div>
                <div className="rounded-2xl bg-white/15 backdrop-blur p-3">
                  <div className="text-2xl font-black">4.8★</div><div className="text-xs font-semibold text-white/80">200+ Reviews</div>
                </div>
                <div className="rounded-2xl bg-white/15 backdrop-blur p-3">
                  <div className="text-2xl font-black">&lt;10m</div><div className="text-xs font-semibold text-white/80">Avg. Ready Time</div>
                </div>
              </div>

              <div className="mt-6 flex items-center gap-3 text-sm font-semibold text-white/90">
                <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-900">Pickup</span>
                <span className="rounded-full bg-white/20 px-3 py-1 text-xs">Delivery — coming soon</span>
                <span>•</span><span>No booking fee</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-[24px] bg-white p-4 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between">
                <div className="font-extrabold">Today&apos;s Specials 🔥</div>
                <Link href="/menu" className="text-xs font-bold text-orange-600">View all →</Link>
              </div>
              <div className="mt-3 grid gap-3">
                {(specials.length ? specials : [
                  { id: 1, name: "Beef Pilau Special", price: "250", discountedPrice: "199", image: null, description: "Fragrant pilau with tender beef, kachumbari & chili" } as any,
                  { id: 2, name: "Chapati + Beans Combo", price: "180", discountedPrice: "140", image: null, description: "2 soft chapos, beans stew & avocado" } as any,
                  { id: 3, name: "Chicken Biryani", price: "350", discountedPrice: "299", image: null, description: "Coastal biryani, raita & kachumbari" } as any,
                ]).map((s: any) => (
                  <div key={s.id} className="flex gap-3 rounded-2xl border border-orange-100 bg-gradient-to-r from-orange-50 to-amber-50 p-3">
                    <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-orange-200 to-amber-200 flex items-center justify-center text-2xl">🍛</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sm leading-tight">{s.name}</div>
                      <div className="text-xs text-slate-600 line-clamp-1">{s.description}</div>
                      <div className="mt-1 flex items-center gap-2">
                        <span className="font-black text-orange-600">KSh {s.discountedPrice ?? s.price}</span>
                        {s.discountedPrice && <span className="text-xs line-through text-slate-400">KSh {s.price}</span>}
                        <span className="ml-auto rounded-full bg-red-500 px-2 py-0.5 text-[10px] font-black text-white">SAVE {s.discountedPrice ? Math.round((1 - Number(s.discountedPrice) / Number(s.price)) * 100) : 20}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[24px] bg-slate-900 p-5 text-white">
              <div className="text-sm font-bold tracking-widest uppercase text-white/60">How it works</div>
              <div className="mt-3 grid grid-cols-3 gap-3 text-center">
                <div><div className="mx-auto h-10 w-10 rounded-full bg-white text-slate-900 flex items-center justify-center font-black">1</div><div className="mt-2 text-xs font-bold">Browse Menu</div><div className="text-[11px] text-white/60">Pick meals</div></div>
                <div><div className="mx-auto h-10 w-10 rounded-full bg-white text-slate-900 flex items-center justify-center font-black">2</div><div className="mt-2 text-xs font-bold">Pay</div><div className="text-[11px] text-white/60">M-Pesa / Cash</div></div>
                <div><div className="mx-auto h-10 w-10 rounded-full bg-white text-slate-900 flex items-center justify-center font-black">3</div><div className="mt-2 text-xs font-bold">Pickup</div><div className="text-[11px] text-white/60">Ready in 10m</div></div>
              </div>
              <div className="mt-4 rounded-2xl bg-white/10 p-3 flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white flex items-center justify-center">📍</div>
                <div><div className="text-sm font-bold">Find us</div><div className="text-xs text-white/70">Royalton, Eldoret — Next to Madonna TTC</div></div>
                <a href="https://maps.google.com/?q=Royalton+Eldoret+Madonna+TTC" target="_blank" className="ml-auto rounded-full bg-white px-4 py-2 text-xs font-black text-slate-900">Directions</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black">Browse by Category</h2>
          <Link href="/menu" className="text-sm font-bold text-orange-600">See full menu →</Link>
        </div>
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { name: "Main Meals", icon: "🍲", desc: "Pilau, Ugali, Rice", color: "from-orange-500 to-amber-500" },
            { name: "Vegetables", icon: "🥬", desc: "Sukuma, Cabbage", color: "from-green-500 to-emerald-500" },
            { name: "Proteins", icon: "🍗", desc: "Beef, Chicken, Beans", color: "from-red-500 to-orange-500" },
            { name: "Drinks", icon: "🥤", desc: "Soda, Juice, Tea", color: "from-sky-500 to-blue-500" },
          ].map(c => (
            <Link key={c.name} href={`/menu?category=${encodeURIComponent(c.name)}`} className="rounded-[20px] bg-white border border-slate-100 p-5 hover:shadow-md transition group">
              <div className={`h-12 w-12 rounded-2xl bg-gradient-to-br ${c.color} flex items-center justify-center text-xl shadow group-hover:scale-105 transition`}>{c.icon}</div>
              <div className="mt-3 font-extrabold">{c.name}</div>
              <div className="text-xs text-slate-500">{c.desc}</div>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-xl font-black">Featured Meals ⭐</h2>
            <p className="text-sm text-slate-600">Most loved by campus students this week</p>
          </div>
          <Link href="/menu" className="hidden sm:inline-flex rounded-full bg-white border px-5 py-2 text-sm font-bold">View Menu</Link>
        </div>
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(featured.length ? featured : [
            { id: 1, name: "Beef Pilau + Kachumbari", price: "250", description: "Aromatic pilau, tender beef cubes, fresh kachumbari", available: true, image: null, popularScore: 98 },
            { id: 2, name: "Ugali + Sukuma + Beef", price: "200", description: "Kenyan classic — fluffy ugali, sukuma wiki, beef stew", available: true, image: null, popularScore: 96 },
            { id: 3, name: "Chapati (2) + Ndengu", price: "150", description: "Soft layered chapati with green grams stew", available: true, image: null, popularScore: 94 },
            { id: 4, name: "Chicken Fry + Chips", price: "320", description: "Crispy chicken, golden chips & coleslaw", available: true, image: null, popularScore: 92 },
            { id: 5, name: "Rice + Beans + Avocado", price: "130", description: "Budget student combo — filing & healthy", available: true, image: null, popularScore: 90 },
            { id: 6, name: "Mokimo + Beef", price: "180", description: "Mashed potatoes + peas + corn with beef", available: true, image: null, popularScore: 88 },
          ]).map((m: any) => (
            <div key={m.id} className="rounded-[20px] bg-white border border-slate-100 overflow-hidden hover:shadow-lg transition">
              <div className="h-36 bg-gradient-to-br from-orange-100 via-amber-50 to-orange-200 flex items-center justify-center text-5xl relative">
                🍛
                <span className="absolute left-3 top-3 rounded-full bg-slate-900 px-2.5 py-1 text-[11px] font-bold text-white">★ {m.popularScore ?? 90} loved</span>
                {!m.available && <span className="absolute right-3 top-3 rounded-full bg-red-500 px-2 py-1 text-xs font-bold text-white">Sold Out</span>}
              </div>
              <div className="p-4">
                <div className="font-extrabold leading-tight">{m.name}</div>
                <div className="text-xs text-slate-600 mt-1 line-clamp-2">{m.description}</div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="font-black text-orange-600">KSh {m.price}</div>
                  <Link href="/menu" className="rounded-full bg-slate-900 px-4 py-1.5 text-xs font-bold text-white">Add to Cart</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* POPULAR COMBOS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
        <div className="rounded-[24px] bg-slate-900 p-6 sm:p-8 text-white">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <h2 className="text-xl font-black">Popular Combinations 🔥</h2>
            <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-bold">Student Budget Friendly</span>
          </div>
          <div className="mt-6 grid md:grid-cols-3 gap-4">
            {[
              { title: "Hostel Survival", items: "Rice + Beans + Soda", price: "180", save: "20" },
              { title: "Weekend Treat", items: "Pilau + Chicken + Juice", price: "380", save: "40" },
              { title: "Veggie Power", items: "Ugali + Sukuma + Ndengu + Tea", price: "200", save: "30" },
            ].map(c => (
              <div key={c.title} className="rounded-2xl bg-white text-slate-900 p-5">
                <div className="text-xs font-black tracking-widest uppercase text-orange-600">{c.title}</div>
                <div className="font-extrabold mt-1">{c.items}</div>
                <div className="mt-3 flex items-center gap-2">
                  <span className="font-black text-lg">KSh {c.price}</span>
                  <span className="rounded-full bg-green-100 px-2 py-1 text-xs font-bold text-green-700">Save KSh {c.save}</span>
                </div>
                <Link href="/menu" className="mt-4 flex w-full justify-center rounded-xl bg-slate-900 py-2.5 text-sm font-bold text-white">Order Combo</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
        <h2 className="text-xl font-black">What Students Say 💬</h2>
        <div className="mt-4 grid md:grid-cols-3 gap-4">
          {(revs.length ? revs : [
            { id: 1, customerName: "Brian K.", rating: 5, comment: "Best pilau near campus! Always hot and on time. Mama's Kitchen is my daily spot.", createdAt: new Date() },
            { id: 2, customerName: "Faith M.", rating: 5, comment: "Affordable and delicious. Chapati + beans combo is unbeatable for the price.", createdAt: new Date() },
            { id: 3, customerName: "Kevin O.", rating: 4, comment: "Quick M-Pesa checkout and food was ready in 7 minutes. Recommend!", createdAt: new Date() },
          ]).map((r: any) => (
            <div key={r.id} className="rounded-2xl bg-white border p-5">
              <div className="flex gap-1 text-amber-500">{"★".repeat(r.rating)}<span className="text-slate-300">{"★".repeat(5 - r.rating)}</span></div>
              <p className="mt-2 text-sm leading-relaxed text-slate-700">&quot;{r.comment}&quot;</p>
              <div className="mt-3 flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold">{r.customerName[0]}</div>
                <div className="text-sm font-bold">{r.customerName}</div>
                <span className="ml-auto text-xs text-slate-500">{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-8 grid md:grid-cols-3 gap-4">
        <div className="rounded-[24px] bg-white border p-6">
          <div className="font-black">Visit Our Kiosk</div>
          <p className="mt-2 text-sm text-slate-600">Royalton Stage, Eldoret<br />Next to Madonna TTC — opposite Royalton Hostels<br />Open daily 6:30 AM – 9:30 PM</p>
          <a href="https://maps.google.com/?q=Royalton+Eldoret+Madonna+TTC" target="_blank" className="mt-4 inline-flex rounded-full bg-slate-900 px-5 py-2.5 text-sm font-bold text-white">Open in Maps</a>
        </div>
        <div className="rounded-[24px] bg-[#25D366] p-6 text-white">
          <div className="font-black">Order on WhatsApp</div>
          <p className="mt-2 text-sm text-white/90">Fastest way — chat, send your order, pay & pickup!</p>
          <div className="mt-3 font-black text-lg">+254 717 565 027</div>
          <a href="https://wa.me/254717565027?text=Hello%20Mama's%20Kitchen!%20I'd%20like%20to%20order." target="_blank" className="mt-4 inline-flex w-full justify-center rounded-full bg-white px-5 py-3 font-black text-[#25D366]">Chat Now</a>
        </div>
        <div className="rounded-[24px] bg-orange-500 p-6 text-white">
          <div className="font-black">Call to Order</div>
          <p className="mt-2 text-sm text-white/90">Prefer calling? We take phone orders too.</p>
          <div className="mt-3 font-black text-lg">+254 717 565 027</div>
          <a href="tel:+254717565027" className="mt-4 inline-flex w-full justify-center rounded-full bg-slate-900 px-5 py-3 font-bold text-white">Call Now</a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
