"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useUser } from "@/lib/userContext";
import { useEffect, useState } from "react";

const nav = [
  { href: "/admin", label: "Overview", icon: "📊" },
  { href: "/admin/menu", label: "Menu", icon: "🍲" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/inventory", label: "Inventory", icon: "📦" },
  { href: "/admin/staff", label: "Staff", icon: "👨‍🍳" },
  { href: "/admin/reports", label: "Reports", icon: "📈" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, loading, logout } = useUser();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.push("/login");
    else if (!loading && user && user.role !== "admin" && user.role !== "staff") {
      // staff can access limited?
      if (pathname?.startsWith("/admin") && !["/admin/orders", "/admin/inventory", "/admin"].includes(pathname)) {
        // allow only orders/inventory for staff
      }
    }
  }, [loading, user, pathname]);

  if (loading) return <div className="min-h-screen grid place-items-center bg-[#FFF8F0]">Loading dashboard…</div>;
  if (!user) return null;
  if (user.role !== "admin" && user.role !== "staff") return <div className="min-h-screen grid place-items-center p-8 text-center"><div><div className="text-4xl">⛔</div><div className="font-black mt-2">Admin only</div><Link href="/login" className="mt-4 inline-flex rounded-full bg-slate-900 px-6 py-2 text-white font-bold">Login as Admin</Link></div></div>;

  const isStaff = user.role === "staff";

  return (
    <div className="min-h-screen bg-[#FFF8F0] flex">
      {/* sidebar desktop */}
      <aside className="hidden lg:flex w-[280px] shrink-0 flex-col bg-slate-900 text-white sticky top-0 h-screen">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center font-black">M</div>
            <div>
              <div className="font-black leading-none">Mama&apos;s Kitchen</div>
              <div className="text-xs text-white/60">Admin Portal • Royalton</div>
            </div>
          </div>
          <div className="mt-4 rounded-2xl bg-white/10 p-3 flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-white text-slate-900 flex items-center justify-center font-bold text-xs">{user.fullName[0]}</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold truncate">{user.fullName}</div>
              <div className="text-xs text-white/60 capitalize">{user.role}</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-auto">
          {nav.filter(n => !isStaff || ["/admin", "/admin/orders", "/admin/inventory"].includes(n.href)).map(item => {
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active ? "bg-white text-slate-900" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
                <span className="text-base">{item.icon}</span> {item.label}
                {item.href === "/admin/orders" && <span className="ml-auto bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">Live</span>}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 space-y-2">
          <Link href="/" className="flex w-full justify-center rounded-xl bg-white/10 py-2.5 text-sm font-bold hover:bg-white/15">← Back to Store</Link>
          <button onClick={async () => { await logout(); router.push("/login"); }} className="w-full rounded-xl bg-red-500 py-2.5 text-sm font-bold hover:bg-red-600">Logout</button>
          <div className="text-center text-xs text-white/40">📍 Royalton, Eldoret<br />+254 717 565 027</div>
        </div>
      </aside>

      {/* mobile header */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="lg:hidden sticky top-0 z-30 bg-slate-900 text-white flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(!open)} className="h-9 w-9 rounded-xl bg-white/10 flex items-center justify-center">☰</button>
            <span className="font-black">Mama&apos;s Admin</span>
          </div>
          <Link href="/" className="rounded-full bg-white text-slate-900 px-4 py-1.5 text-xs font-bold">Store</Link>
        </div>
        {open && (
          <div className="lg:hidden bg-slate-900 text-white p-4 grid grid-cols-2 gap-2">
            {nav.map(item => (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className={`rounded-xl px-3 py-3 text-sm font-bold flex items-center gap-2 ${pathname === item.href ? "bg-white text-slate-900" : "bg-white/10"}`}>
                {item.icon} {item.label}
              </Link>
            ))}
          </div>
        )}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
