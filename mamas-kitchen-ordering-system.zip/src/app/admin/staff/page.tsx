"use client";
import { useEffect, useState } from "react";

export default function StaffPage() {
  const [staff, setStaff] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ fullName:"", email:"", phone:"", password:"", role:"staff" });

  const fetchStaff = async () => {
    const res = await fetch("/api/admin/staff");
    if (res.ok) setStaff(await res.json());
    setLoading(false);
  };
  useEffect(()=>{fetchStaff();},[]);

  const add = async (e:React.FormEvent)=>{
    e.preventDefault();
    const res = await fetch("/api/admin/staff", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(form)});
    if(!res.ok){ alert((await res.json()).error); return; }
    setForm({fullName:"", email:"", phone:"", password:"", role:"staff"});
    fetchStaff();
  };

  const del = async (id:number)=>{
    if(!confirm("Remove staff?"))return;
    setStaff(prev=>prev.filter(s=>s.id!==id));
    await fetch(`/api/admin/staff?id=${id}`, {method:"DELETE"});
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">Staff Management</h1>
        <p className="text-sm text-slate-600">Add staff, assign roles, reset passwords. Staff can view orders & inventory.</p>
      </div>

      <form onSubmit={add} className="rounded-[20px] bg-white border p-5 space-y-3">
        <div className="font-bold">Add Staff / Admin</div>
        <div className="grid sm:grid-cols-2 gap-3">
          <input required value={form.fullName} onChange={e=>setForm({...form, fullName:e.target.value})} placeholder="Full Name" className="rounded-xl border px-3 py-2.5 text-sm"/>
          <input required value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="Email" type="email" className="rounded-xl border px-3 py-2.5 text-sm"/>
          <input value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} placeholder="Phone" className="rounded-xl border px-3 py-2.5 text-sm"/>
          <input required value={form.password} onChange={e=>setForm({...form, password:e.target.value})} placeholder="Password" type="password" className="rounded-xl border px-3 py-2.5 text-sm"/>
        </div>
        <div className="flex gap-2 items-center">
          <select value={form.role} onChange={e=>setForm({...form, role:e.target.value})} className="rounded-xl border px-3 py-2.5 text-sm bg-white">
            <option value="staff">Staff</option>
            <option value="admin">Admin</option>
          </select>
          <button type="submit" className="rounded-full bg-orange-500 px-6 py-2.5 font-bold text-white">+ Add User</button>
          <span className="text-xs text-slate-500">Staff: orders+inventory • Admin: full access</span>
        </div>
      </form>

      {loading ? <div className="h-64 bg-white rounded-2xl animate-pulse border"/> : (
        <div className="rounded-[20px] bg-white border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b text-xs uppercase tracking-widest text-slate-500"><tr><th className="text-left p-3">Name</th><th className="text-left p-3">Email</th><th className="text-left p-3">Role</th><th className="text-left p-3">Phone</th><th className="text-right p-3">Action</th></tr></thead>
              <tbody>
                {staff.map(s=>(
                  <tr key={s.id} className="border-b last:border-0 hover:bg-slate-50">
                    <td className="p-3 font-bold">{s.fullName}</td>
                    <td className="p-3 text-xs">{s.email}</td>
                    <td className="p-3"><span className={`rounded-full px-2 py-1 text-xs font-bold capitalize ${s.role==="admin"?"bg-slate-900 text-white":"bg-orange-100 text-orange-700"}`}>{s.role}</span></td>
                    <td className="p-3">{s.phone||"-"}</td>
                    <td className="p-3 text-right"><button onClick={()=>del(s.id)} className="rounded-full bg-red-50 border border-red-200 px-3 py-1 text-xs font-bold text-red-600">Remove</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
