"use client";
import { useEffect, useState } from "react";

export default function AdminOverview() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    const res = await fetch("/api/admin/stats");
    if (res.ok) setStats(await res.json());
    setLoading(false);
  };
  useEffect(() => { fetchStats(); const iv=setInterval(fetchStats, 5000); return ()=>clearInterval(iv); }, []);

  if (loading) return <div className="space-y-4 animate-pulse"><div className="h-32 bg-white rounded-2xl" /><div className="grid grid-cols-2 gap-4"><div className="h-24 bg-white rounded-2xl"/><div className="h-24 bg-white rounded-2xl"/></div></div>;

  if (!stats) return <div className="rounded-2xl bg-white p-8 text-center border-2 border-dashed">Failed to load stats. Ensure admin login.</div>;

  const cards = [
    { label: "Today's Revenue", value: `KSh ${stats.revenueToday.toFixed(0)}`, sub: `${stats.todayOrders} orders today`, color: "from-emerald-500 to-green-600", icon: "💰" },
    { label: "Pending Orders", value: stats.pending, sub: "Needs action", color: "from-amber-500 to-orange-500", icon: "⏳" },
    { label: "Completed", value: stats.completed, sub: "Total completed", color: "from-slate-700 to-slate-900", icon: "✅" },
    { label: "Low Stock Alert", value: stats.lowStockCount, sub: "Items below threshold", color: "from-red-500 to-rose-600", icon: "⚠️" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black">Dashboard</h1>
          <p className="text-sm text-slate-600">Welcome back! Here&apos;s what&apos;s happening at <b>Royalton, Eldoret</b> today.</p>
        </div>
        <div className="flex gap-2">
          <span className="rounded-full bg-green-50 border border-green-200 px-3 py-1.5 text-xs font-bold text-green-700">● Live • Auto-refresh 5s</span>
          <button onClick={fetchStats} className="rounded-full bg-slate-900 px-5 py-2 text-sm font-bold text-white">Refresh</button>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(c => (
          <div key={c.label} className={`rounded-[20px] bg-gradient-to-br ${c.color} p-5 text-white shadow`}>
            <div className="flex justify-between items-start">
              <div className="text-white/80 text-xs font-bold uppercase tracking-widest">{c.label}</div>
              <div className="h-8 w-8 rounded-xl bg-white/20 flex items-center justify-center">{c.icon}</div>
            </div>
            <div className="text-3xl font-black mt-2">{c.value}</div>
            <div className="text-xs font-semibold text-white/80 mt-1">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-[20px] bg-white border p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-black">Revenue — Last 7 Days</h2>
            <span className="text-xs font-bold text-slate-500">Total KSh {stats.totalRevenue.toFixed(0)} • {stats.totalOrders} orders</span>
          </div>
          <div className="mt-6 flex items-end gap-2 h-[160px]">
            {stats.last7.map((d: any, i: number) => {
              const max = Math.max(...stats.last7.map((x: any)=>x.revenue), 1);
              const h = (d.revenue / max) * 120 + 20;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full rounded-t-xl bg-gradient-to-t from-orange-500 to-amber-400 flex items-end justify-center pb-1 text-xs font-bold text-white" style={{ height: h }}>
                    {d.revenue>0 ? `KSh ${d.revenue}` : ""}
                  </div>
                  <div className="text-xs font-bold">{d.date}</div>
                  <div className="text-[11px] text-slate-500">{d.orders} orders</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-[20px] bg-white border p-6">
          <h2 className="font-black">Popular Meals 🔥</h2>
          <p className="text-xs text-slate-500">Top by popularity score</p>
          <div className="mt-4 space-y-3">
            {stats.popular.map((m: any, idx: number) => (
              <div key={m.id} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-3 border">
                <div className="h-10 w-10 rounded-xl bg-white border flex items-center justify-center font-black text-sm">#{idx+1}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm truncate">{m.name}</div>
                  <div className="text-xs text-slate-500">Score {m.popularScore} • KSh {m.price}</div>
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${m.available ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>{m.available ? "Available" : "Out"}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs">
            <b>💡 Tip:</b> Mark low-stock meals unavailable to avoid pending orders.
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="rounded-[20px] bg-slate-900 p-6 text-white">
          <div className="font-black">Quick Actions</div>
          <div className="mt-3 grid gap-2">
            <a href="/admin/menu" className="rounded-xl bg-white text-slate-900 py-2.5 text-sm font-bold text-center">+ Add New Meal</a>
            <a href="/admin/orders" className="rounded-xl bg-white/10 py-2.5 text-sm font-bold text-center border border-white/20">View Pending Orders</a>
          </div>
        </div>
        <div className="rounded-[20px] bg-white border p-6">
          <div className="font-black">Business Stats</div>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-600">Total Customers</span><b>{stats.totalCustomers}</b></div>
            <div className="flex justify-between"><span className="text-slate-600">Total Orders</span><b>{stats.totalOrders}</b></div>
            <div className="flex justify-between"><span className="text-slate-600">Total Revenue</span><b className="text-green-600">KSh {stats.totalRevenue.toFixed(0)}</b></div>
          </div>
        </div>
        <div className="rounded-[20px] bg-[#25D366] p-6 text-white">
          <div className="font-black">WhatsApp Orders</div>
          <p className="text-sm text-white/90 mt-1">All &quot;Order on WhatsApp&quot; buttons open chat with</p>
          <div className="mt-2 font-black text-lg">+254 717 565 027</div>
          <a href="https://wa.me/254717565027" target="_blank" className="mt-3 inline-flex w-full justify-center rounded-xl bg-white py-2.5 font-bold text-[#25D366] text-sm">Open WhatsApp</a>
        </div>
      </div>
    </div>
  );
}
