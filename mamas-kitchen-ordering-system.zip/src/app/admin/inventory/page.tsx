"use client";
import { useEffect, useState } from "react";

export default function InventoryPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ingredient: "", quantity: "", threshold: "", supplier: "", unit: "kg" });

  const fetchInv = async () => {
    const res = await fetch("/api/admin/inventory");
    if (res.ok) setItems(await res.json());
    setLoading(false);
  };
  useEffect(()=>{ fetchInv(); },[]);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/admin/inventory", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(form)});
    if (res.ok) { setForm({ ingredient:"", quantity:"", threshold:"", supplier:"", unit:"kg"}); fetchInv(); }
  };

  const updateQty = async (id:number, qty:number) => {
    setItems(prev=>prev.map(i=>i.id===id?{...i, quantity:qty}:i));
    await fetch("/api/admin/inventory", { method:"PATCH", headers:{"Content-Type":"application/json"}, body: JSON.stringify({id, quantity:qty})});
  };

  const del = async (id:number) => {
    if(!confirm("Delete item?"))return;
    setItems(prev=>prev.filter(i=>i.id!==id));
    await fetch(`/api/admin/inventory?id=${id}`, {method:"DELETE"});
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-black">Inventory</h1><p className="text-sm text-slate-600">Track stock, suppliers & restock alerts. Low stock highlighted.</p></div>
        <button onClick={fetchInv} className="rounded-full bg-slate-900 px-5 py-2 text-sm font-bold text-white">↻ Refresh</button>
      </div>

      <form onSubmit={add} className="rounded-[20px] bg-white border p-5 grid sm:grid-cols-5 gap-3">
        <input required value={form.ingredient} onChange={e=>setForm({...form, ingredient:e.target.value})} placeholder="Ingredient (e.g. Rice)" className="rounded-xl border px-3 py-2.5 text-sm" />
        <input required value={form.quantity} onChange={e=>setForm({...form, quantity:e.target.value})} placeholder="Qty" type="number" className="rounded-xl border px-3 py-2.5 text-sm" />
        <input required value={form.threshold} onChange={e=>setForm({...form, threshold:e.target.value})} placeholder="Threshold" type="number" className="rounded-xl border px-3 py-2.5 text-sm" />
        <input value={form.supplier} onChange={e=>setForm({...form, supplier:e.target.value})} placeholder="Supplier" className="rounded-xl border px-3 py-2.5 text-sm" />
        <button type="submit" className="rounded-xl bg-orange-500 py-2.5 font-bold text-white">+ Add</button>
      </form>

      {loading ? <div className="h-64 bg-white rounded-2xl animate-pulse border"/> : items.length===0 ? (
        <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center"><div className="text-5xl">📦</div><div className="font-black mt-2">No inventory items</div><p className="text-sm text-slate-500">Add ingredients to track daily usage.</p></div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map(it=>{
            const low = it.quantity <= it.threshold;
            return (
              <div key={it.id} className={`rounded-[20px] border p-5 ${low ? "bg-red-50 border-red-200" : "bg-white"}`}>
                <div className="flex items-start justify-between">
                  <div className="font-black">{it.ingredient}</div>
                  {low ? <span className="rounded-full bg-red-500 px-2 py-1 text-xs font-bold text-white">Low Stock!</span> : <span className="rounded-full bg-green-100 text-green-700 px-2 py-1 text-xs font-bold">OK</span>}
                </div>
                <div className="text-xs text-slate-500">{it.supplier || "No supplier"} • {it.unit}</div>
                <div className="mt-3 h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full ${low?"bg-red-500":"bg-green-500"}`} style={{width:`${Math.min(100, (it.quantity/(it.threshold*2))*100)}%`}}/>
                </div>
                <div className="mt-2 flex items-center justify-between text-sm">
                  <span className="font-bold">{it.quantity} {it.unit} <span className="text-xs font-normal text-slate-500">/ threshold {it.threshold}</span></span>
                  <div className="flex items-center gap-1">
                    <button onClick={()=>updateQty(it.id, Math.max(0,it.quantity-1))} className="h-7 w-7 rounded-full border bg-white flex items-center justify-center font-bold">−</button>
                    <button onClick={()=>updateQty(it.id, it.quantity+1)} className="h-7 w-7 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold">+</button>
                  </div>
                </div>
                <button onClick={()=>del(it.id)} className="mt-3 w-full rounded-xl border bg-white py-1.5 text-xs font-bold text-red-600">Delete</button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
