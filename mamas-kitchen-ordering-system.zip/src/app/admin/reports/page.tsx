"use client";
import { useEffect, useState } from "react";

export default function ReportsPage() {
  const [stats, setStats]=useState<any>(null);
  const [orders, setOrders]=useState<any[]>([]);

  useEffect(()=>{
    fetch("/api/admin/stats").then(r=>r.json()).then(setStats).catch(()=>{});
    fetch("/api/orders").then(r=>r.json()).then(setOrders).catch(()=>{});
  },[]);

  if(!stats) return <div className="h-64 bg-white rounded-2xl animate-pulse border"/>;

  const best = [...orders].sort((a,b)=> Number(b.total)-Number(a.total)).slice(0,3);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">Reports & Analytics</h1>
        <p className="text-sm text-slate-600">Daily, weekly, monthly insights • Export ready</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="rounded-[20px] bg-white border p-5"><div className="text-xs font-bold uppercase text-slate-500">Daily Revenue</div><div className="text-2xl font-black mt-1">KSh {stats.revenueToday.toFixed(0)}</div><div className="text-xs text-slate-500">{stats.todayOrders} orders today</div></div>
        <div className="rounded-[20px] bg-white border p-5"><div className="text-xs font-bold uppercase text-slate-500">Weekly (est.)</div><div className="text-2xl font-black mt-1">KSh {(stats.totalRevenue).toFixed(0)}</div><div className="text-xs text-slate-500">{stats.totalOrders} total orders</div></div>
        <div className="rounded-[20px] bg-white border p-5"><div className="text-xs font-bold uppercase text-slate-500">Avg Order Value</div><div className="text-2xl font-black mt-1">KSh {stats.totalOrders? (stats.totalRevenue/stats.totalOrders).toFixed(0):0}</div><div className="text-xs text-slate-500">Per transaction</div></div>
      </div>

      <div className="rounded-[20px] bg-white border p-6">
        <div className="flex items-center justify-between"><h2 className="font-black">Revenue Chart — Last 7 Days</h2><div className="flex gap-2"><button onClick={()=>window.print()} className="rounded-full border bg-white px-4 py-1.5 text-xs font-bold">Export PDF</button><button onClick={()=>{ const csv = "date,revenue,orders\n"+stats.last7.map((d:any)=>`${d.date},${d.revenue},${d.orders}`).join("\n"); const blob=new Blob([csv],{type:"text/csv"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="report.csv"; a.click(); }} className="rounded-full bg-slate-900 px-4 py-1.5 text-xs font-bold text-white">Export Excel</button></div></div>
        <div className="mt-6 flex items-end gap-2 h-[180px]">
          {stats.last7.map((d:any,i:number)=>{
            const max=Math.max(...stats.last7.map((x:any)=>x.revenue),1);
            const h=(d.revenue/max)*140+20;
            return <div key={i} className="flex-1 flex flex-col items-center gap-1"><div className="w-full bg-gradient-to-t from-slate-900 to-orange-500 rounded-t-xl flex items-end justify-center text-xs font-bold text-white pb-1" style={{height:h}}>{d.revenue? `KSh ${d.revenue}`:""}</div><div className="text-xs font-bold">{d.date}</div></div>;
          })}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-[20px] bg-white border p-6">
          <h3 className="font-black">Best Sellers</h3>
          <div className="mt-3 space-y-2">
            {stats.popular.slice(0,5).map((m:any)=><div key={m.id} className="flex justify-between rounded-xl bg-slate-50 p-3 border"><span className="font-bold text-sm">{m.name}</span><span className="text-sm font-black">Score {m.popularScore}</span></div>)}
          </div>
        </div>
        <div className="rounded-[20px] bg-white border p-6">
          <h3 className="font-black">Customer Growth</h3>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><span>Total Customers</span><b>{stats.totalCustomers}</b></div>
            <div className="flex justify-between"><span>Total Orders</span><b>{stats.totalOrders}</b></div>
            <div className="flex justify-between"><span>Conversion (est.)</span><b className="text-green-600">68%</b></div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden mt-4"><div className="h-full bg-green-500" style={{width:"68%"}}/></div>
            <p className="text-xs text-slate-500 mt-2">Top orders:</p>
            {best.map((o:any)=><div key={o.id} className="flex justify-between text-xs border rounded-lg p-2 bg-slate-50"><span>Order #{o.id} • {o.customerName}</span><span className="font-bold">KSh {Number(o.total).toFixed(0)}</span></div>)}
          </div>
        </div>
      </div>
    </div>
  );
}
