"use client";
import { useEffect, useState } from "react";

const statusOptions = ["received", "preparing", "ready", "completed", "cancelled"];
const statusColors: Record<string,string> = { received: "bg-amber-100 text-amber-800 border-amber-200", preparing: "bg-blue-100 text-blue-800 border-blue-200", ready: "bg-green-100 text-green-800 border-green-200", completed: "bg-slate-900 text-white", cancelled: "bg-red-100 text-red-700 border-red-200" };

export default function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    const res = await fetch("/api/orders");
    if (res.ok) setOrders(await res.json());
    setLoading(false);
  };
  useEffect(()=>{ fetchOrders(); const iv=setInterval(fetchOrders, 4000); return()=>clearInterval(iv); },[]);

  const updateStatus = async (id: number, status: string) => {
    // optimistic
    setOrders(prev => prev.map(o=> o.id===id ? {...o, status}:o));
    await fetch(`/api/orders/${id}`, { method: "PATCH", headers: {"Content-Type":"application/json"}, body: JSON.stringify({status})});
  };

  const filtered = filter==="all" ? orders : orders.filter(o=> o.status===filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black">Orders</h1>
          <p className="text-sm text-slate-600">Live orders — accept, prepare, mark ready. Auto-refresh every 4s.</p>
        </div>
        <button onClick={fetchOrders} className="rounded-full bg-slate-900 px-5 py-2 text-sm font-bold text-white">↻ Refresh</button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2">
        {["all", ...statusOptions].map(s=>(
          <button key={s} onClick={()=>setFilter(s)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold capitalize border ${filter===s ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200"}`}>{s} {s!=="all" && `(${orders.filter(o=>o.status===s).length})`}</button>
        ))}
      </div>

      {loading ? <div className="space-y-3">{Array.from({length:3}).map((_,i)=><div key={i} className="h-32 bg-white rounded-2xl animate-pulse border"/>)}</div> : filtered.length===0 ? (
        <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center">
          <div className="text-5xl">📦</div><div className="font-black mt-2">No {filter} orders</div><p className="text-sm text-slate-500">New customer orders will appear here instantly.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filtered.map(o=>(
            <div key={o.id} className="rounded-[20px] bg-white border p-5">
              <div className="flex flex-wrap gap-4 items-start justify-between">
                <div>
                  <div className="font-black">Order #{o.id} • {o.customerName}</div>
                  <div className="text-sm text-slate-600">{o.customerPhone} • KSh {Number(o.total).toFixed(0)} • {o.paymentMethod} • {o.paymentStatus}</div>
                  <div className="text-xs text-slate-500">{new Date(o.createdAt).toLocaleString()}</div>
                  {o.notes && <div className="mt-2 text-xs bg-amber-50 border border-amber-200 rounded-xl p-2">📝 {o.notes}</div>}
                </div>
                <span className={`rounded-full px-3 py-1.5 text-xs font-black capitalize border ${statusColors[o.status]}`}>{o.status}</span>
              </div>

              <div className="mt-3 rounded-2xl bg-slate-50 border p-3">
                <div className="text-xs font-bold uppercase tracking-wide text-slate-500">Items</div>
                <div className="mt-1 space-y-1 text-sm">
                  {(o.items||[]).map((it:any)=> <div key={it.id} className="flex justify-between"><span>{it.quantity}× {it.name}</span><span className="font-bold">KSh {(Number(it.price)*it.quantity).toFixed(0)}</span></div>)}
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {statusOptions.map(s=>(
                  <button key={s} onClick={()=>updateStatus(o.id, s)} className={`rounded-full px-4 py-1.5 text-xs font-bold capitalize border ${o.status===s ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 hover:bg-slate-50"}`}>{s}</button>
                ))}
                <button onClick={()=>window.print()} className="ml-auto rounded-full bg-white border px-4 py-1.5 text-xs font-bold">🖨️ Print Receipt</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
