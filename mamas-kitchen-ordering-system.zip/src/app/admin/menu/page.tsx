"use client";
import { useEffect, useState } from "react";

type Item = any;

export default function AdminMenu() {
  const [items, setItems] = useState<Item[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [editing, setEditing] = useState<Item | null>(null);
  const [form, setForm] = useState({ name: "", description: "", price: "", categoryId: "", image: "", available: true, isFeatured: false, isSpecial: false, discountedPrice: "" });

  const fetchAll = async () => {
    setLoading(true);
    const [m, c] = await Promise.all([fetch("/api/menu").then(r=>r.json()), fetch("/api/categories").then(r=>r.json()).catch(()=>[])]);
    setItems(m); setCats(c); setLoading(false);
  };
  useEffect(() => { fetchAll(); }, []);

  const openCreate = () => { setEditing(null); setForm({ name: "", description: "", price: "", categoryId: cats[0]?.id ? String(cats[0].id) : "", image: "", available: true, isFeatured: false, isSpecial: false, discountedPrice: "" }); setShow(true); };
  const openEdit = (it: Item) => { setEditing(it); setForm({ name: it.name, description: it.description||"", price: String(it.price), categoryId: it.categoryId?String(it.categoryId):"", image: it.image||"", available: it.available, isFeatured: it.isFeatured, isSpecial: it.isSpecial, discountedPrice: it.discountedPrice||"" }); setShow(true); };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { name: form.name, description: form.description, price: Number(form.price), categoryId: form.categoryId?Number(form.categoryId):null, image: form.image||null, available: form.available, isFeatured: form.isFeatured, isSpecial: form.isSpecial, discountedPrice: form.discountedPrice?Number(form.discountedPrice):null };
    if (editing) await fetch(`/api/menu/${editing.id}`, { method: "PUT", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload)});
    else await fetch("/api/menu", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload)});
    setShow(false); fetchAll();
  };

  const del = async (id: number) => {
    if (!confirm("Delete meal?")) return;
    // optimistic
    setItems(prev => prev.filter(x=>x.id!==id));
    await fetch(`/api/menu/${id}`, { method: "DELETE" });
  };

  const toggleAvail = async (it: Item) => {
    setItems(prev => prev.map(p=> p.id===it.id ? {...p, available: !p.available}:p));
    await fetch(`/api/menu/${it.id}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ available: !it.available })});
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black">Menu Management</h1>
          <p className="text-sm text-slate-600">Add, edit, price & availability — updates reflect instantly on customer menu.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchAll} className="rounded-full border bg-white px-4 py-2 text-sm font-bold">↻ Refresh</button>
          <button onClick={openCreate} className="rounded-full bg-orange-500 px-6 py-2.5 font-black text-white shadow">+ Add Meal</button>
        </div>
      </div>

      {loading ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{Array.from({length:6}).map((_,i)=><div key={i} className="h-48 bg-white rounded-2xl animate-pulse border"/>)}</div> : items.length===0 ? (
        <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center">
          <div className="text-5xl">🍲</div><div className="font-black mt-2">No meals yet</div><p className="text-sm text-slate-500">Create your first meal to populate the store.</p>
          <button onClick={openCreate} className="mt-4 rounded-full bg-slate-900 px-6 py-2.5 font-bold text-white">Add Meal</button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map(it=>(
            <div key={it.id} className="rounded-[20px] bg-white border overflow-hidden flex flex-col">
              <div className="h-36 bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center text-4xl relative">
                {it.image ? <img src={it.image} alt={it.name} className="h-full w-full object-cover"/> : "🍛"}
                <span className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-xs font-bold ${it.available ? "bg-green-500 text-white" : "bg-red-500 text-white"}`}>{it.available ? "Available" : "Unavailable"}</span>
                {it.isSpecial && <span className="absolute right-3 top-3 rounded-full bg-red-500 px-2 py-1 text-xs font-bold text-white">SPECIAL</span>}
              </div>
              <div className="p-4 flex-1">
                <div className="font-extrabold leading-tight">{it.name}</div>
                <div className="text-xs text-slate-600 line-clamp-2 mt-1">{it.description}</div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="font-black text-orange-600">KSh {it.discountedPrice ?? it.price}</span>
                  {it.discountedPrice && <span className="text-xs line-through text-slate-400">KSh {it.price}</span>}
                  <span className="ml-auto text-xs bg-slate-100 px-2 py-1 rounded-full font-semibold">{it.categoryName || "Uncat"}</span>
                </div>
                <div className="mt-3 flex gap-2">
                  <button onClick={()=>openEdit(it)} className="flex-1 rounded-full bg-slate-900 py-2 text-xs font-bold text-white">Edit</button>
                  <button onClick={()=>toggleAvail(it)} className="flex-1 rounded-full border bg-white py-2 text-xs font-bold">{it.available ? "Mark Sold Out" : "Mark Available"}</button>
                  <button onClick={()=>del(it.id)} className="rounded-full bg-red-50 px-3 py-2 text-xs font-bold text-red-600 border border-red-200">🗑️</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {show && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 backdrop-blur-sm p-4" onClick={()=>setShow(false)}>
          <form onClick={e=>e.stopPropagation()} onSubmit={submit} className="w-full max-w-lg rounded-[24px] bg-white p-6 max-h-[90vh] overflow-auto">
            <h2 className="text-xl font-black">{editing ? "Edit Meal" : "Add New Meal"}</h2>
            <p className="text-xs text-slate-500">Upload image URL or leave blank for default emoji.</p>
            <div className="mt-4 space-y-3">
              <input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="Name (e.g. Beef Pilau)" className="w-full rounded-xl border px-3 py-2.5 text-sm" />
              <textarea value={form.description} onChange={e=>setForm({...form, description:e.target.value})} placeholder="Description" rows={2} className="w-full rounded-xl border px-3 py-2.5 text-sm" />
              <div className="grid grid-cols-2 gap-3">
                <input required value={form.price} onChange={e=>setForm({...form, price:e.target.value})} placeholder="Price (KSh)" type="number" className="rounded-xl border px-3 py-2.5 text-sm" />
                <input value={form.discountedPrice} onChange={e=>setForm({...form, discountedPrice:e.target.value})} placeholder="Discounted (optional)" type="number" className="rounded-xl border px-3 py-2.5 text-sm" />
              </div>
              <select value={form.categoryId} onChange={e=>setForm({...form, categoryId:e.target.value})} className="w-full rounded-xl border px-3 py-2.5 text-sm bg-white">
                <option value="">No category</option>
                {cats.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <input value={form.image} onChange={e=>setForm({...form, image:e.target.value})} placeholder="Image URL (optional)" className="w-full rounded-xl border px-3 py-2.5 text-sm" />
              <div className="flex flex-wrap gap-3 text-sm">
                <label className="flex items-center gap-2"><input type="checkbox" checked={form.available} onChange={e=>setForm({...form, available:e.target.checked})}/> Available</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={form.isFeatured} onChange={e=>setForm({...form, isFeatured:e.target.checked})}/> Featured</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={form.isSpecial} onChange={e=>setForm({...form, isSpecial:e.target.checked})}/> Special</label>
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <button type="button" onClick={()=>setShow(false)} className="flex-1 rounded-full border py-3 font-bold">Cancel</button>
              <button type="submit" className="flex-1 rounded-full bg-orange-500 py-3 font-black text-white">{editing ? "Save Changes" : "Create Meal"}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
