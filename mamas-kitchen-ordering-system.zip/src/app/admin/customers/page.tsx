"use client";
import { useEffect, useState } from "react";

export default function AdminCustomers() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCustomers = async () => {
    const res = await fetch("/api/admin/customers");
    if (res.ok) setCustomers(await res.json());
    setLoading(false);
  };
  useEffect(()=>{ fetchCustomers(); },[]);

  const action = async (id:number, act:string) => {
    // optimistic
    if (act==="toggleActive") setCustomers(prev=>prev.map(c=>c.id===id?{...c, isActive:!c.isActive}:c));
    if (act==="resetLoyalty") setCustomers(prev=>prev.map(c=>c.id===id?{...c, loyaltyPoints:0}:c));
    await fetch("/api/admin/customers", { method:"PATCH", headers:{"Content-Type":"application/json"}, body: JSON.stringify({id, action: act})});
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black">Customers</h1>
          <p className="text-sm text-slate-600">View spending, orders & loyalty. Disable accounts or reset points.</p>
        </div>
        <button onClick={fetchCustomers} className="rounded-full bg-slate-900 px-5 py-2 text-sm font-bold text-white">↻ Refresh</button>
      </div>

      {loading ? <div className="h-64 bg-white rounded-2xl animate-pulse border"/> : customers.length===0 ? (
        <div className="rounded-[24px] bg-white border-2 border-dashed p-12 text-center"><div className="text-5xl">👥</div><div className="font-black mt-2">No customers yet</div><p className="text-sm text-slate-500">Customers appear after registration or first order.</p></div>
      ) : (
        <div className="rounded-[20px] bg-white border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b text-xs uppercase tracking-widest text-slate-500">
                <tr><th className="text-left p-3">Customer</th><th className="text-left p-3">Orders</th><th className="text-left p-3">Spent</th><th className="text-left p-3">Points</th><th className="text-left p-3">Status</th><th className="text-right p-3">Actions</th></tr>
              </thead>
              <tbody>
                {customers.map(c=>(
                  <tr key={c.id} className="border-b last:border-0 hover:bg-slate-50">
                    <td className="p-3"><div className="font-bold">{c.fullName}</div><div className="text-xs text-slate-500">{c.email} • {c.phone||"no phone"}</div></td>
                    <td className="p-3 font-bold">{c.totalOrders}</td>
                    <td className="p-3 font-bold text-green-700">KSh {c.totalSpent.toFixed(0)}</td>
                    <td className="p-3"><span className="rounded-full bg-amber-100 text-amber-800 px-2 py-1 text-xs font-bold">{c.loyaltyPoints} pts</span></td>
                    <td className="p-3"><span className={`rounded-full px-2 py-1 text-xs font-bold ${c.isActive?"bg-green-100 text-green-700":"bg-red-100 text-red-700"}`}>{c.isActive?"Active":"Disabled"}</span></td>
                    <td className="p-3 text-right space-x-1">
                      <button onClick={()=>action(c.id,"resetLoyalty")} className="rounded-full border bg-white px-3 py-1 text-xs font-bold">Reset Points</button>
                      <button onClick={()=>action(c.id,"toggleActive")} className={`rounded-full px-3 py-1 text-xs font-bold ${c.isActive?"bg-red-500 text-white":"bg-green-600 text-white"}`}>{c.isActive?"Disable":"Enable"}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
