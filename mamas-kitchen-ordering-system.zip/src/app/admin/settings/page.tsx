"use client";
import { useState } from "react";

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    businessName: "Mama's Kitchen",
    phone: "+254 717 565 027",
    whatsapp: "+254717565027",
    location: "Royalton, Eldoret — Next to Madonna TTC",
    hours: "6:30 AM - 9:30 PM",
    tax: "0",
    theme: "light",
  });
  const [saved, setSaved] = useState(false);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-black">Settings</h1>
        <p className="text-sm text-slate-600">Business info, WhatsApp, hours, tax & theme. Saved locally (demo).</p>
      </div>

      <div className="rounded-[20px] bg-white border p-6 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <div><label className="text-xs font-bold">Business Name</label><input value={settings.businessName} onChange={e=>setSettings({...settings, businessName:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/></div>
          <div><label className="text-xs font-bold">Phone</label><input value={settings.phone} onChange={e=>setSettings({...settings, phone:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/></div>
          <div><label className="text-xs font-bold">WhatsApp Number</label><input value={settings.whatsapp} onChange={e=>setSettings({...settings, whatsapp:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/><p className="text-xs text-green-600 mt-1">All &quot;Order on WhatsApp&quot; uses this</p></div>
          <div><label className="text-xs font-bold">Opening Hours</label><input value={settings.hours} onChange={e=>setSettings({...settings, hours:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/></div>
        </div>
        <div><label className="text-xs font-bold">Location</label><input value={settings.location} onChange={e=>setSettings({...settings, location:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/></div>
        <div className="grid sm:grid-cols-3 gap-4">
          <div><label className="text-xs font-bold">Tax %</label><input value={settings.tax} onChange={e=>setSettings({...settings, tax:e.target.value})} type="number" className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm"/></div>
          <div><label className="text-xs font-bold">Theme</label><select value={settings.theme} onChange={e=>setSettings({...settings, theme:e.target.value})} className="mt-1 w-full rounded-xl border px-3 py-2.5 text-sm bg-white"><option value="light">Light</option><option value="dark">Dark</option></select></div>
          <div className="flex items-end"><button onClick={()=>{setSaved(true); setTimeout(()=>setSaved(false),2000);}} className="w-full rounded-full bg-slate-900 py-2.5 font-bold text-white">Save Settings</button></div>
        </div>
        {saved && <div className="rounded-xl bg-green-50 border border-green-200 p-3 text-sm font-bold text-green-700">✓ Settings saved (demo persistence)</div>}
      </div>

      <div className="rounded-[20px] bg-slate-900 p-6 text-white">
        <div className="font-black">Payment Settings</div>
        <div className="mt-3 space-y-2 text-sm">
          <div className="flex justify-between"><span>M-Pesa STK Push</span><span className="rounded-full bg-green-500 px-3 py-1 text-xs font-bold">Enabled (Demo)</span></div>
          <div className="flex justify-between"><span>Cash on Pickup</span><span className="rounded-full bg-white text-slate-900 px-3 py-1 text-xs font-bold">Enabled</span></div>
          <div className="flex justify-between"><span>WhatsApp Business API</span><span className="rounded-full bg-[#25D366] px-3 py-1 text-xs font-bold">Connected +254717565027</span></div>
        </div>
        <p className="mt-3 text-xs text-white/60">Safaricom Daraja API & WhatsApp notifications are edge functions (demo auto-confirm).</p>
      </div>

      <div className="rounded-[20px] bg-amber-50 border border-amber-200 p-4 text-sm">
        <b>🔒 Security</b> — Admin-only access, audit logs, session timeout 30 mins, 2FA future. Current session secured via JWT HttpOnly cookie.
      </div>
    </div>
  );
}
