import Navbar from "@/components/Navbar";
import { Suspense } from "react";
import OrdersContent from "./OrdersContent";

export const dynamic = "force-dynamic";

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-[#FFF8F0]">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 py-6">
        <Suspense fallback={<div className="p-8 text-center">Loading orders…</div>}>
          <OrdersContent />
        </Suspense>
      </div>
    </div>
  );
}
