"use client";
import { useEffect, useState } from "react";
import { useUser } from "@/lib/userContext";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

type Order = any;

const statusSteps = ["received", "preparing", "ready", "completed"];
const statusLabels: Record<string, string> = { received: "Received", preparing: "Preparing", ready: "Ready for Pickup", completed: "Completed", cancelled: "Cancelled" };
const statusColors: Record<string, string> = { received: "bg-amber-100 text-amber-700", preparing: "bg-blue-100 text-blue-700", ready: "bg-green-100 text-green-700", completed: "bg-slate-900 text-white", cancelled: "bg-red-100 text-red-700" };

export default function OrdersContent() {
  const { user } = useUser();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Order | null>(null);
  const searchParams = useSearchParams();
  const successId = searchParams.get("success");

  const fetchOrders = async () => {
    setLoading(true);
    try {
      if (user) {
        const res = await fetch(`/api/orders?mine=true`);
        if (res.ok) setOrders(await res.json());
        else {
          const all = await fetch(`/api/orders`).then(r => r.json()).catch(() => []);
          setOrders(all);
        }
      } else {
        const stored = localStorage.getItem("mk_last_order");
        if (stored) {
          const id = JSON.parse(stored).id;
          const r = await fetch(`/api/orders/${id}`).then(res => res.json()).catch(() => null);
          if (r && r.id) setOrders([r]);
        }
      }
    } finally { setLoading(false); }
  };

  useEffect(() => {
    if (successId) {
      localStorage.setItem("mk_last_order", JSON.stringify({ id: successId }));
      fetch(`/api/orders/${successId}`).then(r=>r.json()).then(o=> { if(o.id) setSelected(o); }).catch(()=>{});
    }
  }, [successId]);

  useEffect(() => { fetchOrders(); }, [user]);

  useEffect(() => {
    if (!selected) return;
    const iv = setInterval(async () => {
      const r = await fetch(`/api/orders/${selected.id}`).then(x=>x.json()).catch(()=>null);
      if (r && r.status !== selected.status) setSelected(r);
    }, 5000);
    return () => clearInterval(iv);
  }, [selected]);

  return (
    <div>
        {successId && (
          <div className="rounded-[20px] bg-green-600 p-6 text-white mb-6">
            <div className="text-3xl">🎉</div>
            <div className="text-xl font-black mt-1">Order Placed! #{successId}</div>
            <p className="text-white/90 text-sm mt-1">We&apos;re preparing your meal at Royalton, Eldoret. Track status below — we&apos;ll update in real-time.</p>
            <div className="mt-3 flex gap-2">
              <a href="https://wa.me/254717565027" target="_blank" className="rounded-full bg-white px-5 py-2 text-sm font-bold text-green-700">Chat on WhatsApp</a>
              <span className="rounded-full bg-white/20 px-4 py-2 text-sm font-semibold">Pickup in ~10 mins</span>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black">Order Tracking</h1>
          <button onClick={fetchOrders} className="rounded-full bg-white border px-4 py-2 text-sm font-bold">↻ Refresh</button>
        </div>
        <p className="text-sm text-slate-600">Live status • Real-time updates every 5 seconds • Pickup at kiosk</p>

        {selected && (
          <div className="mt-6 rounded-[24px] bg-white border p-6 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="text-sm font-bold tracking-widest uppercase text-slate-500">Order #{selected.id}</div>
                <div className="font-black text-lg">{selected.customerName} • {selected.customerPhone}</div>
                <div className="text-sm text-slate-600">Total KSh {Number(selected.total).toFixed(0)} • {selected.paymentMethod === "mpesa" ? "M-Pesa Paid" : "Cash on Pickup"}</div>
              </div>
              <span className={`rounded-full px-4 py-1.5 text-sm font-black ${statusColors[selected.status] ?? "bg-slate-100"}`}>{statusLabels[selected.status]}</span>
            </div>

            <div className="mt-6 relative">
              <div className="absolute top-5 left-5 right-5 h-1 bg-slate-100 rounded-full hidden sm:block" />
              <div className="absolute top-5 left-5 h-1 bg-green-500 rounded-full hidden sm:block transition-all" style={{ width: `${(statusSteps.indexOf(selected.status) / (statusSteps.length - 1))* 100}%`, maxWidth: "90%" }} />
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative">
                {statusSteps.map((s, i) => {
                  const active = statusSteps.indexOf(selected.status) >= i;
                  const current = selected.status === s;
                  return (
                    <div key={s} className={`rounded-2xl border-2 p-3 text-center ${current ? "border-green-500 bg-green-50" : active ? "border-green-200 bg-white" : "border-slate-100 bg-slate-50 opacity-60"}`}>
                      <div className={`mx-auto h-10 w-10 rounded-full flex items-center justify-center font-black text-sm ${active ? "bg-green-500 text-white" : "bg-slate-200 text-slate-600"}`}>{active ? "✓" : i+1}</div>
                      <div className="mt-2 text-xs font-black uppercase tracking-wide">{statusLabels[s]}</div>
                      <div className="text-[11px] text-slate-500">{s === "received" ? "Order received" : s === "preparing" ? "Kitchen cooking" : s === "ready" ? "Come pickup!" : "Enjoy!"}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 rounded-2xl bg-slate-50 p-4">
              <div className="font-bold text-sm">Items</div>
              <div className="mt-2 space-y-1.5 text-sm">
                {(selected.items || []).map((it: any) => (
                  <div key={it.id} className="flex justify-between"><span>{it.quantity}× {it.name}</span><span className="font-bold">KSh {(Number(it.price)*it.quantity).toFixed(0)}</span></div>
                ))}
              </div>
              {selected.notes && <div className="mt-3 text-xs bg-white rounded-xl p-2 border">📝 Note: {selected.notes}</div>}
            </div>

            <div className="mt-4 rounded-2xl bg-amber-50 border border-amber-200 p-3 flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-amber-500 flex items-center justify-center text-white">📍</div>
              <div><div className="font-bold text-sm">Pickup Location</div><div className="text-xs text-slate-700">Royalton, Eldoret — Next to Madonna TTC. Show this order # at counter.</div></div>
            </div>

            <button onClick={() => setSelected(null)} className="mt-4 text-sm font-bold text-slate-600 hover:underline">← Back to all orders</button>
          </div>
        )}

        {!selected && (
          <>
            {loading ? (
              <div className="mt-6 space-y-3">
                {Array.from({length:3}).map((_,i)=><div key={i} className="h-24 bg-white rounded-2xl animate-pulse border" />)}
              </div>
            ) : orders.length === 0 ? (
              <div className="mt-8 rounded-[24px] bg-white border-2 border-dashed p-12 text-center">
                <div className="text-5xl">📦</div>
                <div className="mt-3 font-black text-lg">No orders yet</div>
                <p className="text-sm text-slate-500">Place your first order and track it live here. Your loyalty points will appear in profile.</p>
                <div className="mt-6 flex justify-center gap-3">
                  <Link href="/menu" className="rounded-full bg-orange-500 px-7 py-3 font-bold text-white">Order Now</Link>
                  {!user && <Link href="/login" className="rounded-full border bg-white px-7 py-3 font-bold">Login to see history</Link>}
                </div>
              </div>
            ) : (
              <div className="mt-6 space-y-3">
                {orders.map(o => (
                  <div key={o.id} onClick={() => setSelected(o)} className="rounded-2xl bg-white border p-4 flex flex-wrap items-center gap-4 hover:shadow-md cursor-pointer transition">
                    <div className="h-12 w-12 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black">#{o.id}</div>
                    <div className="flex-1 min-w-[200px]">
                      <div className="font-bold">{o.customerName} • KSh {Number(o.total).toFixed(0)}</div>
                      <div className="text-xs text-slate-600">{new Date(o.createdAt).toLocaleString()} • {(o.items||[]).length} items • {o.paymentMethod}</div>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-black ${statusColors[o.status]}`}>{statusLabels[o.status]}</span>
                    <span className="text-xs font-bold text-orange-600 hidden sm:block">View →</span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
    </div>
  );
}
