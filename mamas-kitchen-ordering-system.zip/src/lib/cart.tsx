"use client";
import React, { createContext, useContext, useEffect, useState } from "react";

export type CartItem = {
  id: number;
  name: string;
  price: number;
  discountedPrice?: number | null;
  image?: string | null;
  quantity: number;
};

type CartContextType = {
  items: CartItem[];
  addItem: (item: Omit<CartItem, "quantity">, qty?: number) => void;
  removeItem: (id: number) => void;
  updateQty: (id: number, qty: number) => void;
  clear: () => void;
  total: number;
  count: number;
};

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("mk_cart");
    if (stored) {
      try { setItems(JSON.parse(stored)); } catch {}
    }
  }, []);
  useEffect(() => {
    localStorage.setItem("mk_cart", JSON.stringify(items));
  }, [items]);

  const addItem = (item: Omit<CartItem, "quantity">, qty = 1) => {
    setItems(prev => {
      const existing = prev.find(p => p.id === item.id);
      if (existing) return prev.map(p => p.id === item.id ? { ...p, quantity: p.quantity + qty } : p);
      return [...prev, { ...item, quantity: qty }];
    });
  };
  const removeItem = (id: number) => setItems(prev => prev.filter(p => p.id !== id));
  const updateQty = (id: number, qty: number) => {
    if (qty <= 0) return removeItem(id);
    setItems(prev => prev.map(p => p.id === id ? { ...p, quantity: qty } : p));
  };
  const clear = () => setItems([]);
  const total = items.reduce((sum, i) => sum + (i.discountedPrice ?? i.price) * i.quantity, 0);
  const count = items.reduce((sum, i) => sum + i.quantity, 0);

  return <CartContext.Provider value={{ items, addItem, removeItem, updateQty, clear, total, count }}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be inside CartProvider");
  return ctx;
}
