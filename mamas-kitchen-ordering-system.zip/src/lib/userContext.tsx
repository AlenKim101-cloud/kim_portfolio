"use client";
import React, { createContext, useContext, useEffect, useState } from "react";

type User = { id: number; email: string; fullName: string; role: string; phone?: string | null };

type Ctx = {
  user: User | null;
  loading: boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
};

const UserContext = createContext<Ctx>({ user: null, loading: true, refresh: async () => {}, logout: async () => {} });

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else setUser(null);
    } catch { setUser(null); }
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
  };

  return <UserContext.Provider value={{ user, loading, refresh, logout }}>{children}</UserContext.Provider>;
}

export const useUser = () => useContext(UserContext);
